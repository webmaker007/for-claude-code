/* PWA — register the service worker so the browser "Download" /
   Install button can offer a real installable, offline-capable app.
   Skipped entirely on file:// (this Electron desktop build) —
   service workers don't apply there, and fetch() can't load file://
   URLs at all, so registering one there would just break local
   resource loading instead of helping.

   Also keeps the web version self-updating: sw.js calls
   skipWaiting()/clients.claim() on every new version, so a
   newly-fetched service worker takes over almost immediately. The
   controllerchange listener below catches that handover and
   reloads the page once, so anyone with the app already open
   converges to the current build within a couple of seconds. */

if (
  "serviceWorker" in navigator &&
  (window.location.protocol === "https:" ||
    window.location.protocol === "http:")
) {
  let swRefreshing = false;

  navigator.serviceWorker.addEventListener("controllerchange", () => {
    if (swRefreshing) {
      return;
    }

    swRefreshing = true;

    window.location.reload();
  });

  window.addEventListener("load", () => {
    navigator.serviceWorker
      .register("./sw.js")
      .then((reg) => {
        /* Ask the browser to re-check sw.js for a new version right
           away, then again whenever the tab regains focus, rather
           than relying solely on the browser's own update timing. */

        reg.update().catch(() => {});

        document.addEventListener("visibilitychange", () => {
          if (document.visibilityState === "visible") {
            reg.update().catch(() => {});
          }
        });
      })
      .catch((err) => console.warn("[pwa] service worker failed:", err));
  });
}

const API = "https://pokeapi.co/api/v2/pokemon/";

const POKEMON_COUNT = 1029;

const ARTWORK_BASE =
  "https://raw.githubusercontent.com/PokeAPI/sprites/master/" +
  "sprites/pokemon/other/official-artwork/";

const SPRITE_FALLBACK_BASE =
  "https://raw.githubusercontent.com/PokeAPI/sprites/master/" +
  "sprites/pokemon/";

const CAPTURED_STORAGE_KEY = "pf_captured_pokemon";

const SELECTED_STORAGE_KEY = "pf_selected_fighter";

const COINS_KEY = "pf_coins_v1";
const GEMS_KEY = "pf_gems_v1";
const RANK_INDEX_KEY = "pf_rank_index_v1";
const RANK_WINS_KEY = "pf_rank_wins_v1";
const WIN_STREAK_KEY = "pf_win_streak_v1";
const BEST_STREAK_KEY = "pf_best_streak_v1";
const SETTINGS_KEY = "pf_settings_v1";
const GOOGLE_PROFILE_KEY = "pf_google_profile_v1";

const CLOUD_SYNCED_AT_KEY = "pf_cloud_synced_at";

/* ============================================================
   FIREBASE — Google sign-in (real, server-verified sessions) +
   Firestore (cross-device cloud save)
============================================================

Auth: Firebase Auth's Google provider replaces the earlier
"decode the JWT in the browser" approach — Firebase verifies the
sign-in properly, so request.auth.uid in Firestore security rules
can actually be trusted.

Storage: local per-account storage (nsKey() below) still exists
and is still what the rest of the game reads/writes moment to
moment — it's fast and works offline. Firestore is layered on
top purely for cross-device sync:
  - On sign-in (or when a different account than last time is
    detected), pull that account's cloud save (if any) into local
    storage, then reload so the whole app boots under it.
  - While playing, every save also schedules a debounced push of
    the current state up to Firestore.
  - On every load where you're already signed in, a quick
    background check compares the cloud save's timestamp to what
    was last synced locally — if another device saved something
    newer, it's pulled down and the page reloads once.
============================================================ */

const firebaseConfig = {
  apiKey: "AIzaSyB9znUIMoIj8Z1vz3m7fQSa6z2kVSt4j1I",
  authDomain: "pokemon-fighters-ac320.firebaseapp.com",
  projectId: "pokemon-fighters-ac320",
  storageBucket: "pokemon-fighters-ac320.firebasestorage.app",
  messagingSenderId: "624604328425",
  appId: "1:624604328425:web:49d986c08f51ca230c1b78",
  measurementId: "G-H06KF7XZ88",
};

let fbAuth = null;
let fbDb = null;

try {
  if (window.firebase && firebase.initializeApp) {
    firebase.initializeApp(firebaseConfig);
    fbAuth = firebase.auth();
    fbDb = firebase.firestore();
  }
} catch (e) {
  console.warn("[firebase] init failed:", e);
}

let googleProfile = loadGoogleProfile();

/* ------------------------------------------------------------
   PER-ACCOUNT STORAGE NAMESPACING

   Sign-in is now required to use the app (see #auth-gate in
   index.html). Every piece of saved progress (coins, gems, rank,
   captured Pokémon, selected team, settings…) is namespaced by
   the signed-in Google account's `sub` (its stable unique ID), so
   two different accounts on the same device/browser never share
   or overwrite each other's save data.
------------------------------------------------------------ */

function accountNamespace() {
  return googleProfile && googleProfile.sub ? googleProfile.sub : "guest";
}

function nsKey(baseKey) {
  return baseKey + "__acct_" + accountNamespace();
}

function loadGoogleProfile() {
  try {
    const raw = localStorage.getItem(GOOGLE_PROFILE_KEY);

    return raw ? JSON.parse(raw) : null;
  } catch (e) {
    return null;
  }
}

function saveGoogleProfile() {
  try {
    if (googleProfile) {
      localStorage.setItem(GOOGLE_PROFILE_KEY, JSON.stringify(googleProfile));
    } else {
      localStorage.removeItem(GOOGLE_PROFILE_KEY);
    }
  } catch (e) {
    /* Non-fatal. */
  }
}

function buildProfileFromFirebaseUser(user) {
  return {
    name: user.displayName || "",
    given_name: (user.displayName || "").split(" ")[0] || "",
    email: user.email || "",
    picture: user.photoURL || "",
    sub: user.uid,
  };
}

function startGoogleSignIn() {
  /* Electron desktop build: a browser-embedded Google popup can't
     work from a file:// origin (Google requires a real, authorized
     web origin for that flow — see main.js for why). Use the real
     desktop OAuth flow exposed by preload.js instead: it opens the
     person's system browser to sign in there, then hands back a
     Google ID token here, which we exchange for a normal Firebase
     session via signInWithCredential(). Everything downstream
     (onAuthStateChanged, per-account storage, cloud sync) is then
     identical to the web version — it has no idea which path was
     used to sign in. */

  if (window.electronAPI && window.electronAPI.isElectron) {
    startElectronGoogleSignIn();

    return;
  }

  if (!fbAuth || !window.firebase) {
    showToast({
      icon: "⚠️",
      title: "Sign-in unavailable",
      message: "Firebase didn't load. Check your connection and try again.",
      tone: "error",
    });

    return;
  }

  const provider = new firebase.auth.GoogleAuthProvider();

  fbAuth.signInWithPopup(provider).catch((err) => {
    if (err && err.code === "auth/popup-closed-by-user") {
      return;
    }

    showToast({
      icon: "⚠️",
      title: "Sign-in failed",
      message: (err && err.message) || "Please try again.",
      tone: "error",
    });
  });
}

function startElectronGoogleSignIn() {
  if (!fbAuth || !window.firebase) {
    showToast({
      icon: "⚠️",
      title: "Sign-in unavailable",
      message: "Firebase didn't load. Check your connection and try again.",
      tone: "error",
    });

    return;
  }

  showToast({
    icon: "🌐",
    title: "Opening your browser…",
    message: "Finish signing in there, then come back to the app.",
  });

  window.electronAPI
    .signInWithGoogle()
    .then((result) => {
      if (!result || !result.ok) {
        if (result && result.error && result.error !== "timed_out") {
          showToast({
            icon: "⚠️",
            title: "Sign-in didn't complete",
            message:
              result.error === "invalid_state_or_code" ||
              (result.error || "").startsWith("Desktop Google Sign-In")
                ? result.error
                : "You can try again from Settings.",
            tone: "error",
          });
        }

        return;
      }

      const credential = firebase.auth.GoogleAuthProvider.credential(
        result.idToken,
      );

      fbAuth.signInWithCredential(credential).catch((err) => {
        showToast({
          icon: "⚠️",
          title: "Sign-in failed",
          message: (err && err.message) || "Please try again.",
          tone: "error",
        });
      });
    })
    .catch(() => {
      showToast({
        icon: "⚠️",
        title: "Sign-in failed",
        message: "Something went wrong opening your browser.",
        tone: "error",
      });
    });
}

function handleGoogleSignOut() {
  if (fbAuth) {
    fbAuth.signOut().catch(() => {});
  }

  googleProfile = null;

  saveGoogleProfile();

  try {
    sessionStorage.setItem(
      "pf_pending_toast",
      JSON.stringify({ icon: "👋", title: "Signed out" }),
    );
  } catch (e) {
    /* Non-fatal. */
  }

  /* Reload so the sign-in gate reappears and no in-memory state from
     the signed-out account lingers on screen. */

  location.reload();
}

/* ------------------------------------------------------------
   CLOUD SYNC (Firestore)
------------------------------------------------------------ */

function cloudDocFor(uid) {
  return fbDb.collection("players").doc(uid);
}

function applyCloudDataToLocalStorage(uid, data) {
  const ns = (base) => base + "__acct_" + uid;

  try {
    if (typeof data.coins === "number") {
      localStorage.setItem(ns(COINS_KEY), String(data.coins));
    }

    if (typeof data.gems === "number") {
      localStorage.setItem(ns(GEMS_KEY), String(data.gems));
    }

    if (typeof data.rankIndex === "number") {
      localStorage.setItem(ns(RANK_INDEX_KEY), String(data.rankIndex));
    }

    if (typeof data.rankWins === "number") {
      localStorage.setItem(ns(RANK_WINS_KEY), String(data.rankWins));
    }

    if (typeof data.winStreak === "number") {
      localStorage.setItem(ns(WIN_STREAK_KEY), String(data.winStreak));
    }

    if (typeof data.bestStreak === "number") {
      localStorage.setItem(ns(BEST_STREAK_KEY), String(data.bestStreak));
    }

    if (Array.isArray(data.captured)) {
      localStorage.setItem(ns(CAPTURED_STORAGE_KEY), JSON.stringify(data.captured));
    }

    if (Array.isArray(data.team)) {
      localStorage.setItem(ns(SELECTED_TEAM_KEY), JSON.stringify(data.team));
    }

    if (data.settings && typeof data.settings === "object") {
      localStorage.setItem(ns(SETTINGS_KEY), JSON.stringify(data.settings));
    }

    if (typeof data.selected === "string") {
      localStorage.setItem(ns(SELECTED_STORAGE_KEY), data.selected);
    }

    if (typeof data.updatedAt === "number") {
      localStorage.setItem(ns(CLOUD_SYNCED_AT_KEY), String(data.updatedAt));
    }
  } catch (e) {
    /* Non-fatal. */
  }
}

/* Pulls this account's cloud save (if any) down into local storage,
   then reloads the page so the whole app boots fresh under it. Used
   right after a sign-in, or when switching to a different account
   than whatever was cached locally. */

function pullCloudProgressThenReload() {
  if (!fbDb || !googleProfile) {
    location.reload();

    return;
  }

  const uid = googleProfile.sub;

  cloudDocFor(uid)
    .get()
    .then((snap) => {
      if (snap.exists) {
        applyCloudDataToLocalStorage(uid, snap.data());
      }
    })
    .catch((err) => {
      console.warn("[cloud] pull failed:", err);
    })
    .finally(() => {
      try {
        sessionStorage.setItem(
          "pf_pending_toast",
          JSON.stringify({
            icon: "✅",
            title: "Signed in with Google",
            message:
              googleProfile.given_name ||
              googleProfile.name ||
              googleProfile.email,
            tone: "success",
          }),
        );
      } catch (e) {
        /* Non-fatal. */
      }

      location.reload();
    });
}

/* For an already-signed-in return visit: checks whether another
   device has saved something newer than what's synced locally, and
   if so, pulls it down and reloads once. Doesn't touch anything if
   the local save is already current. */

function backgroundCloudSyncCheck() {
  if (!fbDb || !googleProfile) {
    return;
  }

  const uid = googleProfile.sub;

  cloudDocFor(uid)
    .get()
    .then((snap) => {
      if (!snap.exists) {
        return;
      }

      const data = snap.data();

      const cloudUpdatedAt =
        typeof data.updatedAt === "number" ? data.updatedAt : 0;

      const localSyncedAt = loadStoredNumber(CLOUD_SYNCED_AT_KEY, 0);

      /* A little slack avoids reacting to our own very-recent push. */

      if (cloudUpdatedAt > localSyncedAt + 1000) {
        applyCloudDataToLocalStorage(uid, data);

        try {
          sessionStorage.setItem(
            "pf_pending_toast",
            JSON.stringify({
              icon: "☁️",
              title: "Synced progress from another device",
            }),
          );
        } catch (e) {
          /* Non-fatal. */
        }

        location.reload();
      }
    })
    .catch((err) => {
      console.warn("[cloud] background sync check failed:", err);
    });
}

function pushCloudProgress() {
  if (!fbDb || !googleProfile) {
    return;
  }

  const uid = googleProfile.sub;

  const now = Date.now();

  const payload = {
    coins: loadStoredNumber(COINS_KEY, 0),
    gems: loadStoredNumber(GEMS_KEY, 0),
    rankIndex: loadStoredNumber(RANK_INDEX_KEY, 0),
    rankWins: loadStoredNumber(RANK_WINS_KEY, 0),
    winStreak: loadStoredNumber(WIN_STREAK_KEY, 0),
    bestStreak: loadStoredNumber(BEST_STREAK_KEY, 0),
    captured: loadCapturedList(),
    team: loadSelectedTeamNames(),
    settings: loadSettings(),
    selected: (() => {
      try {
        return localStorage.getItem(nsKey(SELECTED_STORAGE_KEY)) || "";
      } catch (e) {
        return "";
      }
    })(),
    updatedAt: now,
  };

  cloudDocFor(uid)
    .set(payload, { merge: true })
    .then(() => {
      try {
        localStorage.setItem(nsKey(CLOUD_SYNCED_AT_KEY), String(now));
      } catch (e) {
        /* Non-fatal. */
      }
    })
    .catch((err) => {
      console.warn("[cloud] push failed:", err);
    });
}

let cloudPushTimer = null;

/* Call this from every "save" primitive below — it debounces so a
   burst of rapid changes (e.g. leveling through a battle) becomes
   one Firestore write shortly after things settle down. */

function scheduleCloudPush() {
  if (!fbDb || !googleProfile) {
    return;
  }

  if (cloudPushTimer) {
    clearTimeout(cloudPushTimer);
  }

  cloudPushTimer = setTimeout(() => {
    cloudPushTimer = null;

    pushCloudProgress();
  }, 1500);
}

/* Reflects sign-in state in the topbar avatar and the Settings
   modal's Account section. Safe to call any time — no-ops if the
   relevant elements aren't in the DOM yet. */

function updateGoogleAccountUI() {
  const topbarAvatar = document.getElementById("topbar-avatar");

  if (topbarAvatar) {
    if (googleProfile && googleProfile.picture) {
      topbarAvatar.innerHTML =
        '<img src="' +
        googleProfile.picture +
        '" alt="" referrerpolicy="no-referrer" />';
    } else {
      topbarAvatar.textContent = "⚡";
    }
  }

  const signedOutEl = document.getElementById("google-signin-container");

  const signedInEl = document.getElementById("google-account-info");

  if (!signedOutEl || !signedInEl) {
    return;
  }

  if (googleProfile) {
    signedOutEl.classList.add("hidden");

    signedInEl.classList.remove("hidden");

    const avatar = document.getElementById("google-account-avatar");

    const name = document.getElementById("google-account-name");

    const email = document.getElementById("google-account-email");

    if (avatar) {
      avatar.src = googleProfile.picture || "";
    }

    if (name) {
      name.textContent =
        googleProfile.name || googleProfile.given_name || "Trainer";
    }

    if (email) {
      email.textContent = googleProfile.email || "";
    }
  } else {
    signedOutEl.classList.remove("hidden");

    signedInEl.classList.add("hidden");
  }
}

/* Wires the "Sign in with Google" button in the Settings modal. */

function initGoogleSignIn() {
  updateGoogleAccountUI();

  const container = document.getElementById("google-signin-container");

  if (!container) {
    return;
  }

  container.innerHTML =
    '<button type="button" class="google-btn" id="settings-google-btn">' +
    '<img src="https://www.gstatic.com/firebasejs/ui/2.0.0/images/auth/google.svg" alt="" /> Sign in with Google</button>';

  const btn = document.getElementById("settings-google-btn");

  if (btn) {
    btn.addEventListener("click", startGoogleSignIn);
  }
}

/* ============================================================
   AUTH STATE — the single source of truth for whether we're
   signed in. Fires once on load with whatever session Firebase
   already has cached (or null), and again on every sign-in/out.
============================================================ */

if (fbAuth) {
  fbAuth.onAuthStateChanged((user) => {
    if (user) {
      const profile = buildProfileFromFirebaseUser(user);

      const isSameAccount = googleProfile && googleProfile.sub === profile.sub;

      googleProfile = profile;

      saveGoogleProfile();

      if (!isSameAccount) {
        /* A brand-new sign-in on this device, or a different account
           than whatever was cached — pull that account's cloud save
           (if any) and reload fresh under it. */

        pullCloudProgressThenReload();
      } else {
        /* Same account as already loaded — just check whether
           another device has saved something newer. */

        backgroundCloudSyncCheck();
      }
    } else if (googleProfile) {
      /* Firebase says signed out (session expired, or signed out on
         another tab/device) but we still have a cached profile —
         clear it and show the gate. */

      googleProfile = null;

      saveGoogleProfile();

      location.reload();
    }
  });
}

/* ============================================================
   SIGN-IN GATE — blocks access to the app until the trainer signs
   in with Google. Progress is namespaced per account (see
   nsKey() above), so this also determines *whose* save data the
   rest of the app loads.
============================================================ */

function initAuthGate() {
  const gate = document.getElementById("auth-gate");

  if (!gate) {
    return;
  }

  if (googleProfile) {
    gate.classList.add("hidden");

    document.documentElement.classList.add("pf-authed");
    document.documentElement.classList.remove("pf-gate");

    return;
  }

  document.documentElement.classList.add("pf-gate");
  document.documentElement.classList.remove("pf-authed");

  gate.classList.remove("hidden");

  const container = document.getElementById("gate-google-signin-container");

  const hint = document.getElementById("gate-hint");

  if (!container) {
    return;
  }

  container.innerHTML =
    '<button type="button" class="google-btn google-btn-lg" id="gate-google-btn">' +
    '<img src="https://www.gstatic.com/firebasejs/ui/2.0.0/images/auth/google.svg" alt="" /> Sign in with Google</button>';

  const btn = document.getElementById("gate-google-btn");

  if (btn) {
    btn.addEventListener("click", startGoogleSignIn);
  }

  if (!fbAuth && hint) {
    hint.textContent =
      "Firebase didn't load. Check your connection or ad blocker, then refresh.";

    hint.classList.remove("hidden");
  }
}

/* Replays a toast queued just before a sign-in/sign-out reload
   (see pullCloudProgressThenReload / handleGoogleSignOut /
   backgroundCloudSyncCheck). */

function replayPendingToast() {
  try {
    const raw = sessionStorage.getItem("pf_pending_toast");

    if (!raw) {
      return;
    }

    sessionStorage.removeItem("pf_pending_toast");

    const opts = JSON.parse(raw);

    if (opts) {
      showToast(opts);
    }
  } catch (e) {
    /* Non-fatal. */
  }
}

/* ============================================================
   TOUCH CONTROLS (on-screen buttons for phones/tablets — mirror
   Player 1's keyboard controls by dispatching the same key
   events game.js already listens for, so game.js itself needs
   no changes)
============================================================ */

function dispatchGameKey(type, key, code) {
  window.dispatchEvent(
    new KeyboardEvent(type, {
      key,
      code: code || key,
      bubbles: true,
      cancelable: true,
    }),
  );
}

function wireTapButton(id, key, code) {
  const el = document.getElementById(id);

  if (!el) {
    return;
  }

  const press = (e) => {
    e.preventDefault();

    dispatchGameKey("keydown", key, code);

    dispatchGameKey("keyup", key, code);
  };

  el.addEventListener("pointerdown", press);
}

function wireHoldButton(id, key, code) {
  const el = document.getElementById(id);

  if (!el) {
    return;
  }

  const down = (e) => {
    e.preventDefault();

    el.classList.add("touch-btn-active");

    dispatchGameKey("keydown", key, code);
  };

  const up = (e) => {
    if (e) e.preventDefault();

    el.classList.remove("touch-btn-active");

    dispatchGameKey("keyup", key, code);
  };

  el.addEventListener("pointerdown", down);

  el.addEventListener("pointerup", up);

  el.addEventListener("pointercancel", up);

  el.addEventListener("pointerleave", up);
}

/* DOWNLOAD BUTTON — downloads the real desktop app (.exe installer).
   Deliberately does NOT use `beforeinstallprompt` / the browser's own
   "install as web app" prompt — that installs a stripped-down browser
   window, not the actual Pokémon Fighter app, which is not what this
   button is for. */

// URL of the built Windows installer (electron-builder / NSIS .exe).
// This MUST exactly match the filename you upload to /downloads/ on
// your Netlify site (case + punctuation, including underscores vs dots).
const WINDOWS_INSTALLER_URL =
  "https://github.com/webmaker007/Arman/releases/download/v1.0.0/Pokemon-Fighter-Setup-1_0_0.exe";
const WINDOWS_INSTALLER_FILENAME = "Pokemon-Fighter-Setup-1_0_0.exe";

function isWindows() {
  const uaPlatform =
    navigator.userAgentData?.platform || navigator.platform || "";
  return /Win/i.test(uaPlatform) || /Windows/i.test(navigator.userAgent);
}

function downloadWindowsInstaller() {
  const link = document.createElement("a");
  link.href = WINDOWS_INSTALLER_URL;
  link.download = WINDOWS_INSTALLER_FILENAME;
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);

  showToast({
    icon: "⬇",
    title: "Downloading installer",
    message:
      "Once it finishes, open the .exe and follow the setup wizard to install Pokémon Fighter.",
    duration: 6000,
  });
}

function initInstallPrompt() {
  const installBtn = document.getElementById("install-app-btn");

  if (!installBtn) return;

  // This button always downloads the real desktop app (.exe) — it no
  // longer falls back to the browser's own "install as web app"
  // prompt, which is a different thing (a stripped-down browser
  // window) from actually installing your app.
  installBtn.onclick = () => {
    if (isWindows()) {
      downloadWindowsInstaller();
      return;
    }

    // No Windows build detected for this visitor's OS yet — download
    // the Windows installer anyway (it's the only build that exists),
    // but be upfront that it's Windows-only for now.
    showToast({
      icon: "⬇",
      title: "Windows app only (for now)",
      message:
        "Pokémon Fighter's downloadable app is currently built for Windows. Downloading the .exe now — Mac/Linux support is coming later.",
      duration: 6000,
    });

    downloadWindowsInstaller();
  };
}

function initTouchControls() {
  wireHoldButton("touch-left", "a");

  wireHoldButton("touch-right", "d");

  wireTapButton("touch-jump", "w");

  wireTapButton("touch-attack", "s");

  wireTapButton("touch-dodge", "q");

  wireTapButton("touch-switch", "Tab", "Tab");

  wireHoldButton("touch-block", "Shift", "ShiftLeft");
}

/* Tiers a trainer climbs through in the League — promotion needs
   WINS_PER_PROMOTION league wins within the current tier. */

const RANK_TIERS = [
  { name: "Bronze III", icon: "🥉" },
  { name: "Bronze II", icon: "🥉" },
  { name: "Bronze I", icon: "🥉" },
  { name: "Silver III", icon: "🥈" },
  { name: "Silver II", icon: "🥈" },
  { name: "Silver I", icon: "🥈" },
  { name: "Gold III", icon: "🥇" },
  { name: "Gold II", icon: "🥇" },
  { name: "Gold I", icon: "🥇" },
  { name: "Platinum III", icon: "💠" },
  { name: "Platinum II", icon: "💠" },
  { name: "Platinum I", icon: "💠" },
  { name: "Diamond", icon: "💎" },
  { name: "Master", icon: "👑" },
];

const WINS_PER_PROMOTION = 3;

const STAT_LABELS = ["HP", "ATK", "DEF", "SP.ATK", "SP.DEF", "SPD"];

/* Small built-in list used only if the full roster call fails. */

const OFFLINE_ROSTER = [
  { name: "pikachu", id: 25 },
  { name: "charizard", id: 6 },
  { name: "lucario", id: 448 },
  { name: "gengar", id: 94 },
  { name: "greninja", id: 658 },
  { name: "blaziken", id: 257 },
  { name: "gyarados", id: 130 },
  { name: "dragonite", id: 149 },
  { name: "tyranitar", id: 248 },
  { name: "eevee", id: 133 },
];

const DEFAULT_STARTER = { name: "pikachu", id: 25 };

let selected = null;

let opponent = null;

let capturedList = loadCapturedList();

const SELECTED_TEAM_KEY = "pf_selected_team";

let teamSelection = new Set(
  loadSelectedTeamNames().filter((n) => capturedList.some((p) => p.name === n)),
);

/* Search query for Player 1's team-select grid — only used in
   2-player mode, when P1 (like P2) picks from the full Pokédex
   instead of just their captured list. */
let teamSelectQuery = "";

let teamSelectSearchTimer = null;

/* Player 2's team (local 2-player mode) is picked from the full
   Pokédex, not the captured list — P2 doesn't have their own
   "captured" pool in this single-device app. */

const SELECTED_TEAM_P2_KEY = "pf_selected_team_p2";

let p2TeamSelection = new Set(loadSelectedTeamP2Names());

let selectedName = getPersistedSelectedName();

let rosterList = null;

let rosterLoading = null;

let activeCategory = "all";

let currentSearchQuery = "";

const typeListCache = {};

/* Local 2-player toggle — when on, Player 2 controls the
   opponent team with the keyboard instead of the AI. */
let twoPlayerModeEnabled = false;

/* Evolution: how long a captured Pokémon spends in your Pokédex
   before it evolves, and how often we check for it. */
const EVOLVE_AFTER_MS = 3 * 60 * 1000;
const EVOLUTION_CHECK_MS = 30 * 1000;
const evolutionChainCache = {};

/* ============================================================
   LEAGUE / ECONOMY STATE (coins, gems, rank, win streak)
============================================================ */

let coins = loadStoredNumber(COINS_KEY, 2450);

let gems = loadStoredNumber(GEMS_KEY, 180);

let rankIndex = clampNumber(
  loadStoredNumber(RANK_INDEX_KEY, 0),
  0,
  RANK_TIERS.length - 1,
);

let rankWins = loadStoredNumber(RANK_WINS_KEY, 0);

let winStreak = loadStoredNumber(WIN_STREAK_KEY, 4);

let bestStreak = loadStoredNumber(BEST_STREAK_KEY, 4);

/* Set true right before a battle launched from the League screen so
   handleBattleFinished() knows to apply rank rewards on top of the
   usual capture logic. */

let pendingLeagueMatch = false;

/* ============================================================
   SETTINGS (trainer name, sound, AI difficulty)
============================================================ */

let settings = loadSettings();

window.AI_DIFFICULTY = settings.difficulty;

/* Auto-fill the trainer name from the signed-in Google account the
   first time this account is seen — never clobber a name the
   trainer already chose for this account. */

if (
  googleProfile &&
  (!settings.trainerName ||
    settings.trainerName.trim() === "Player One" ||
    !settings.trainerName.trim())
) {
  settings.trainerName = (
    googleProfile.given_name ||
    googleProfile.name ||
    "Player One"
  ).slice(0, 16);

  saveSettings();
}

function loadSettings() {
  const defaults = {
    trainerName: "Player One",
    sound: true,
    difficulty: "normal",
  };

  try {
    const raw = localStorage.getItem(nsKey(SETTINGS_KEY));

    const parsed = raw ? JSON.parse(raw) : null;

    if (parsed && typeof parsed === "object") {
      return { ...defaults, ...parsed };
    }
  } catch (e) {
    /* Ignore, fall through to defaults. */
  }

  return defaults;
}

function saveSettings() {
  try {
    localStorage.setItem(nsKey(SETTINGS_KEY), JSON.stringify(settings));
  } catch (e) {
    /* Non-fatal. */
  }

  scheduleCloudPush();
}

function loadStoredNumber(key, fallback) {
  try {
    const raw = localStorage.getItem(nsKey(key));

    const n = raw === null ? NaN : Number(raw);

    return Number.isFinite(n) ? n : fallback;
  } catch (e) {
    return fallback;
  }
}

function saveStoredNumber(key, value) {
  try {
    localStorage.setItem(nsKey(key), String(value));
  } catch (e) {
    /* Non-fatal. */
  }

  scheduleCloudPush();
}

/* ============================================================
   TOAST NOTIFICATIONS (dynamic in-app alerts — no blocking
   window.alert()/window.confirm() dialogs anywhere in the app)
============================================================ */

function showToast(opts) {
  const config =
    typeof opts === "string"
      ? { message: opts }
      : opts && typeof opts === "object"
        ? opts
        : {};

  const {
    icon = "",
    title = "",
    message = "",
    duration = 3400,
    tone = "",
  } = config;

  const container = document.getElementById("toast-container");

  if (!container) {
    return;
  }

  const el = document.createElement("div");

  el.className = "toast" + (tone ? " toast-" + tone : "");

  el.innerHTML =
    (icon ? '<span class="toast-icon">' + icon + "</span>" : "") +
    '<div class="toast-body">' +
    (title ? "<b>" + title + "</b>" : "") +
    (message ? "<span>" + message + "</span>" : "") +
    "</div>";

  container.appendChild(el);

  requestAnimationFrame(() => el.classList.add("show"));

  const remove = () => {
    el.classList.remove("show");

    el.classList.add("hide");

    setTimeout(() => el.remove(), 260);
  };

  el.onclick = remove;

  setTimeout(remove, duration);
}

/* ============================================================
   SOUND EFFECTS (tiny WebAudio beeps — no external audio files,
   respects the Settings "Sound Effects" toggle)
============================================================ */

let audioCtx = null;

function ensureAudioCtx() {
  if (audioCtx) {
    return audioCtx;
  }

  try {
    audioCtx = new (window.AudioContext || window.webkitAudioContext)();
  } catch (e) {
    audioCtx = null;
  }

  return audioCtx;
}

function playTone(freq, duration, type, gainPeak) {
  if (!settings.sound) {
    return;
  }

  const ctx = ensureAudioCtx();

  if (!ctx) {
    return;
  }

  const osc = ctx.createOscillator();

  const gain = ctx.createGain();

  osc.type = type || "sine";

  osc.frequency.value = freq;

  gain.gain.value = 0;

  osc.connect(gain).connect(ctx.destination);

  const now = ctx.currentTime;

  gain.gain.linearRampToValueAtTime(gainPeak || 0.16, now + 0.02);

  gain.gain.exponentialRampToValueAtTime(0.001, now + duration);

  osc.start(now);

  osc.stop(now + duration + 0.05);
}

function sfxClick() {
  playTone(520, 0.07, "square", 0.1);
}

function sfxCapture() {
  playTone(660, 0.12, "sine", 0.16);

  setTimeout(() => playTone(880, 0.18, "sine", 0.16), 110);
}

function sfxEvolve() {
  playTone(440, 0.12, "sine", 0.16);

  setTimeout(() => playTone(660, 0.12, "sine", 0.16), 120);

  setTimeout(() => playTone(880, 0.22, "sine", 0.16), 240);
}

function sfxWin() {
  playTone(523, 0.1, "sine", 0.16);

  setTimeout(() => playTone(659, 0.1, "sine", 0.16), 100);

  setTimeout(() => playTone(784, 0.22, "sine", 0.16), 200);
}

function sfxLose() {
  playTone(300, 0.2, "sawtooth", 0.09);

  setTimeout(() => playTone(220, 0.3, "sawtooth", 0.09), 150);
}

document.addEventListener("DOMContentLoaded", async () => {
  /* SIGN-IN GATE — do this first, before anything else wires up. */

  initAuthGate();

  replayPendingToast();

  const normal = document.getElementById("btn-normal-battle");

  const ranked = document.getElementById("btn-ranked-battle");

  /* CAPTURED COUNT */

  updateCapturedCountUI();

  /* RESOURCES / TRAINER NAME */

  updateResourcesUI();

  updateTrainerNameUI();

  /* 2-PLAYER TOGGLE */

  const toggle2p = document.getElementById("toggle-2p");

  if (toggle2p) {
    toggle2p.onclick = () => {
      twoPlayerModeEnabled = !twoPlayerModeEnabled;

      toggle2p.classList.toggle("active", twoPlayerModeEnabled);

      const label = document.getElementById("mode-toggle-label");

      if (label) {
        label.textContent = twoPlayerModeEnabled ? "2P" : "1P";
      }

      toggle2p.title = twoPlayerModeEnabled
        ? "2-player mode — Player 2 controls the opponent with arrow keys"
        : "1-player mode — the opponent is AI-controlled";

      syncFighterPreviewForMode().catch(() => {});
    };
  }

  /* EVOLUTION — check periodically, plus once shortly after load
     to catch anything that finished evolving while you were away. */

  setTimeout(checkEvolutions, 5000);

  setInterval(checkEvolutions, EVOLUTION_CHECK_MS);

  /* HOW TO PLAY */

  document.getElementById("btn-info").onclick = openInfoModal;

  document.getElementById("info-close").onclick = closeInfoModal;

  document.getElementById("info-modal").onclick = (e) => {
    if (e.target.id === "info-modal") {
      closeInfoModal();
    }
  };

  /* POKÉDEX / ROSTER */

  document.getElementById("btn-captured").onclick = openRoster;

  document.getElementById("roster-back").onclick = closeRoster;

  document.getElementById("roster-search").oninput = handleRosterSearch;

  document.querySelectorAll(".type-chip").forEach((chip) => {
    chip.onclick = () => setCategory(chip.dataset.type);
  });

  document.getElementById("pokedex-close").onclick = closePokedex;

  document.getElementById("pokedex-modal").onclick = (e) => {
    if (e.target.id === "pokedex-modal") {
      closePokedex();
    }
  };

  /* SETTINGS */

  document.getElementById("settings").onclick = openSettings;

  document.getElementById("settings-close").onclick = closeSettings;

  document.getElementById("settings-modal").onclick = (e) => {
    if (e.target.id === "settings-modal") {
      closeSettings();
    }
  };

  document.getElementById("settings-trainer-name").oninput = (e) => {
    settings.trainerName = e.target.value.slice(0, 16);

    saveSettings();

    updateTrainerNameUI();
  };

  document.getElementById("settings-sound-toggle").onclick = () => {
    settings.sound = !settings.sound;

    saveSettings();

    const btn = document.getElementById("settings-sound-toggle");

    btn.classList.toggle("active", settings.sound);

    btn.setAttribute("aria-pressed", settings.sound ? "true" : "false");

    if (settings.sound) {
      playTone(660, 0.1, "sine", 0.16);
    }
  };

  document.querySelectorAll("#settings-difficulty button").forEach((btn) => {
    btn.onclick = () => {
      settings.difficulty = btn.dataset.value;

      saveSettings();

      window.AI_DIFFICULTY = settings.difficulty;

      document.querySelectorAll("#settings-difficulty button").forEach((b) => {
        b.classList.toggle("active", b === btn);
      });

      sfxClick();
    };
  });

  document.getElementById("settings-reset").onclick = handleResetProgressClick;

  /* ACCOUNT (Google Sign-In) */

  initGoogleSignIn();

  const googleSignOutBtn = document.getElementById("google-signout-btn");

  if (googleSignOutBtn) {
    googleSignOutBtn.onclick = handleGoogleSignOut;
  }

  /* TOUCH CONTROLS (phones/tablets) */

  initTouchControls();

  /* INSTALL / DOWNLOAD (laptop) */

  initInstallPrompt();

  /* HOME */

  document.getElementById("back-home").onclick = () => {
    location.reload();
  };

  /* Let game.js report battle outcomes back here for the capture mechanic. */

  window.onBattleFinished = handleBattleFinished;

  /* LOAD POKEMON */

  await loadFighters();

  /* START MATCH */

  normal.onclick = openTeamSelect;

  ranked.onclick = openLeague;

  document.getElementById("league-back").onclick = closeLeague;

  document.getElementById("league-battle-btn").onclick = () => {
    pendingLeagueMatch = true;

    /* League is solo vs. AI only — local multiplayer isn't offered
       for ranked matches, so force 1-player mode even if the global
       2P toggle was left on from a Normal match. */

    if (twoPlayerModeEnabled) {
      twoPlayerModeEnabled = false;

      if (toggle2p) {
        toggle2p.classList.remove("active");
      }

      const label = document.getElementById("mode-toggle-label");

      if (label) {
        label.textContent = "1P";
      }

      if (toggle2p) {
        toggle2p.title = "1-player mode — the opponent is AI-controlled";
      }
    }

    closeLeague();

    openTeamSelect();
  };

  /* TEAM SELECT MODAL (Player 1 — from your captured Pokémon) */

  document.getElementById("team-select-close").onclick = closeTeamSelect;

  document.getElementById("team-select-cancel").onclick = closeTeamSelect;

  document.getElementById("team-select-modal").onclick = (e) => {
    if (e.target.id === "team-select-modal") {
      closeTeamSelect();
    }
  };

  document.getElementById("team-select-confirm").onclick = () => {
    saveSelectedTeamNames();

    closeTeamSelect();

    if (twoPlayerModeEnabled) {
      openTeamSelectP2();
    } else {
      startBattle();
    }
  };

  /* TEAM SELECT MODAL (Player 2 — local 2-player mode, from the
     full Pokédex, since P2 has no captured list of their own). */

  document.getElementById("team-select-p2-close").onclick = closeTeamSelectP2;

  document.getElementById("team-select-p2-cancel").onclick = closeTeamSelectP2;

  document.getElementById("team-select-p2-modal").onclick = (e) => {
    if (e.target.id === "team-select-p2-modal") {
      closeTeamSelectP2();
    }
  };

  document.getElementById("team-select-p2-confirm").onclick = () => {
    saveSelectedTeamP2Names();

    closeTeamSelectP2();

    syncFighterPreviewForMode().catch(() => {});

    startBattle();
  };

  document.getElementById("team-select-p2-search").oninput =
    handleTeamSelectP2Search;

  const teamSelectSearch = document.getElementById("team-select-search");

  if (teamSelectSearch) {
    teamSelectSearch.oninput = handleTeamSelectSearch;
  }

  /* Warm the roster list in the background so the picker opens instantly. */

  ensureRosterList().catch(() => {});
});

/* ============================================================
   RESOURCES / TRAINER NAME UI
============================================================ */

function updateResourcesUI() {
  const coinsEl = document.getElementById("coins");

  if (coinsEl) {
    coinsEl.textContent = coins.toLocaleString();
  }

  const gemsEl = document.getElementById("gems");

  if (gemsEl) {
    gemsEl.textContent = gems.toLocaleString();
  }

  const rankEl = document.getElementById("rank-label");

  if (rankEl) {
    rankEl.textContent = RANK_TIERS[rankIndex].name.toUpperCase();
  }

  const streakEl = document.getElementById("win-streak-label");

  if (streakEl) {
    streakEl.textContent = winStreak + " 🔥";
  }
}

function updateTrainerNameUI() {
  const label = document.getElementById("trainer-name-label");

  if (label) {
    label.textContent = (settings.trainerName || "").trim() || "Player One";
  }
}

/* ============================================================
   HOW TO PLAY MODAL
============================================================ */

function openInfoModal() {
  const body = document.getElementById("info-body");

  if (body) {
    body.innerHTML =
      "<div><h4>CONTROLS</h4>" +
      "<p>Player 1: W jump • A/D move • S attack • Q dodge • Shift block • Tab switch Pokémon</p>" +
      "<p>Player 2 (turn on 2P mode on Home first): ↑ jump • ←/→ move • ↓ attack • / dodge • Right Shift block • Enter switch Pokémon</p></div>" +
      "<div><h4>BATTLING</h4>" +
      "<p>Attack after the warning telegraph appears. Jump or dodge to avoid incoming hits.</p></div>" +
      "<div><h4>SWITCHING MID-FIGHT</h4>" +
      "<p>Press Tab (or click a bright team dot above the health bar) to swap in another Pokémon from your team without waiting for a faint.</p></div>" +
      "<div><h4>LOCAL 2-PLAYER</h4>" +
      "<p>Turn on 2P mode on Home, then hit Battle. Both trainers pick their own 6 from the full Pokédex before the fight starts. Nobody's Pokémon get captured in 2P matches — it's trainer vs trainer.</p></div>" +
      "<div><h4>CAPTURING & BUYING POKÉMON</h4>" +
      "<p>In 1-player mode, win a battle to capture your opponent's Pokémon. You can also open any wild Pokémon's Pokédex entry and buy it outright with coins or gems — no battle required. You can only battle using Pokémon you've captured — check the Captured tab in the Pokédex to see and pick your team.</p></div>" +
      "<div><h4>EVOLUTION</h4>" +
      "<p>Captured Pokémon evolve on their own after spending time in your Pokédex — check back and watch your team grow stronger. You can still browse any Pokémon's stats in the Pokédex, but only captured ones can fight.</p></div>" +
      "<div><h4>LEAGUE</h4>" +
      "<p>Win League battles to earn coins and gems, build a win streak, and climb the rank ladder from Bronze all the way to Master.</p></div>";
  }

  document.getElementById("info-modal").classList.remove("hidden");
}

function closeInfoModal() {
  document.getElementById("info-modal").classList.add("hidden");
}

/* ============================================================
   SETTINGS MODAL
============================================================ */

let resetArmed = false;

function openSettings() {
  const nameInput = document.getElementById("settings-trainer-name");

  if (nameInput) {
    nameInput.value = settings.trainerName || "";
  }

  const soundToggle = document.getElementById("settings-sound-toggle");

  if (soundToggle) {
    soundToggle.classList.toggle("active", settings.sound);

    soundToggle.setAttribute("aria-pressed", settings.sound ? "true" : "false");
  }

  document.querySelectorAll("#settings-difficulty button").forEach((b) => {
    b.classList.toggle("active", b.dataset.value === settings.difficulty);
  });

  resetDangerButton();

  document.getElementById("settings-modal").classList.remove("hidden");
}

function closeSettings() {
  document.getElementById("settings-modal").classList.add("hidden");
}

function resetDangerButton() {
  resetArmed = false;

  const btn = document.getElementById("settings-reset");

  if (btn) {
    btn.textContent = "Reset Progress";

    btn.classList.remove("armed");
  }
}

function handleResetProgressClick() {
  const btn = document.getElementById("settings-reset");

  if (!resetArmed) {
    resetArmed = true;

    if (btn) {
      btn.textContent = "Tap again to confirm";

      btn.classList.add("armed");
    }

    setTimeout(() => {
      if (resetArmed) {
        resetDangerButton();
      }
    }, 4000);

    return;
  }

  [
    CAPTURED_STORAGE_KEY,
    SELECTED_STORAGE_KEY,
    SELECTED_TEAM_KEY,
    COINS_KEY,
    GEMS_KEY,
    RANK_INDEX_KEY,
    RANK_WINS_KEY,
    WIN_STREAK_KEY,
    BEST_STREAK_KEY,
    SETTINGS_KEY,
  ].forEach((key) => {
    try {
      /* Only this account's data — nsKey() namespaces every one of
         these by the signed-in account, so other accounts that have
         played on this device are untouched. */

      localStorage.removeItem(nsKey(key));
    } catch (e) {
      /* Non-fatal. */
    }
  });

  try {
    localStorage.removeItem(SELECTED_TEAM_P2_KEY);
  } catch (e) {
    /* Non-fatal. */
  }

  /* Also clear the cloud save for this account so it doesn't come
     back on this or any other device's next sync check. */

  if (fbDb && googleProfile) {
    cloudDocFor(googleProfile.sub)
      .delete()
      .catch((err) => console.warn("[cloud] reset delete failed:", err));
  }

  showToast({
    icon: "♻️",
    title: "Progress reset",
    message: "Starting fresh — reloading…",
  });

  setTimeout(() => location.reload(), 900);
}

/* ============================================================
   LEAGUE SCREEN
============================================================ */

function openLeague() {
  renderLeagueScreen();

  document.getElementById("home-page").classList.add("hidden");

  document.getElementById("league-page").classList.remove("hidden");
}

function closeLeague() {
  document.getElementById("league-page").classList.add("hidden");

  document.getElementById("home-page").classList.remove("hidden");
}

function renderLeagueScreen() {
  const tier = RANK_TIERS[rankIndex];

  const isMaxRank = rankIndex >= RANK_TIERS.length - 1;

  const iconEl = document.getElementById("league-rank-icon");

  if (iconEl) {
    iconEl.textContent = tier.icon;
  }

  const nameEl = document.getElementById("league-rank-name");

  if (nameEl) {
    nameEl.textContent = tier.name;
  }

  const fillEl = document.getElementById("league-progress-fill");

  if (fillEl) {
    fillEl.style.width = isMaxRank
      ? "100%"
      : Math.round((rankWins / WINS_PER_PROMOTION) * 100) + "%";
  }

  const progressLabelEl = document.getElementById("league-progress-label");

  if (progressLabelEl) {
    progressLabelEl.textContent = isMaxRank
      ? "Top rank reached!"
      : rankWins + "/" + WINS_PER_PROMOTION + " wins to promote";
  }

  const streakEl = document.getElementById("league-streak-value");

  if (streakEl) {
    streakEl.textContent = winStreak + " 🔥";
  }

  const bestEl = document.getElementById("league-best-streak-value");

  if (bestEl) {
    bestEl.textContent = String(bestStreak);
  }

  const coinsEl = document.getElementById("league-coins-value");

  if (coinsEl) {
    coinsEl.textContent = coins.toLocaleString();
  }

  const gemsEl = document.getElementById("league-gems-value");

  if (gemsEl) {
    gemsEl.textContent = gems.toLocaleString();
  }
}

function saveLeagueState() {
  saveStoredNumber(COINS_KEY, coins);

  saveStoredNumber(GEMS_KEY, gems);

  saveStoredNumber(RANK_INDEX_KEY, rankIndex);

  saveStoredNumber(RANK_WINS_KEY, rankWins);

  saveStoredNumber(WIN_STREAK_KEY, winStreak);

  saveStoredNumber(BEST_STREAK_KEY, bestStreak);
}

function applyLeagueResult(playerWon) {
  if (playerWon) {
    winStreak += 1;

    bestStreak = Math.max(bestStreak, winStreak);

    rankWins += 1;

    const coinReward = 50 + winStreak * 10;

    coins += coinReward;

    let gemReward = 0;

    if (Math.random() < 0.35) {
      gemReward = 1 + Math.floor(Math.random() * 3);

      gems += gemReward;
    }

    let promoted = false;

    if (rankWins >= WINS_PER_PROMOTION && rankIndex < RANK_TIERS.length - 1) {
      rankWins = 0;

      rankIndex += 1;

      promoted = true;
    }

    saveLeagueState();

    updateResourcesUI();

    sfxWin();

    const rewardText =
      "+" + coinReward + " 🥮" + (gemReward ? " +" + gemReward + " 💎" : "");

    if (promoted) {
      showToast({
        icon: "🏆",
        title: "Promoted to " + RANK_TIERS[rankIndex].name + "!",
        message: rewardText,
        tone: "success",
        duration: 4200,
      });
    } else {
      showToast({
        icon: "⚔",
        title: "League Win!",
        message: rewardText + " • Streak " + winStreak,
        tone: "success",
      });
    }
  } else {
    winStreak = 0;

    let demoted = false;

    if (rankWins === 0 && rankIndex > 0) {
      rankIndex -= 1;

      rankWins = Math.max(0, WINS_PER_PROMOTION - 1);

      demoted = true;
    } else {
      rankWins = Math.max(0, rankWins - 1);
    }

    saveLeagueState();

    updateResourcesUI();

    sfxLose();

    showToast({
      icon: demoted ? "📉" : "💔",
      title: demoted ? "Demoted" : "League Loss",
      message: demoted
        ? "Dropped to " + RANK_TIERS[rankIndex].name + ". Your streak is reset."
        : "Win streak reset. Keep battling to climb the ranks!",
      tone: "error",
    });
  }

  if (!document.getElementById("league-page").classList.contains("hidden")) {
    renderLeagueScreen();
  }
}

/* ============================================================
   CAPTURED POKÉMON (persisted in localStorage)
============================================================ */

function loadCapturedList() {
  try {
    const raw = localStorage.getItem(nsKey(CAPTURED_STORAGE_KEY));

    const parsed = raw ? JSON.parse(raw) : null;

    if (Array.isArray(parsed) && parsed.length) {
      /* Backfill capturedAt on entries saved before the evolution
         feature existed, so they start their evolution clock now
         instead of evolving instantly. */

      let changed = false;

      parsed.forEach((p) => {
        if (!p.capturedAt) {
          p.capturedAt = Date.now();
          changed = true;
        }
      });

      if (changed) {
        try {
          localStorage.setItem(
            nsKey(CAPTURED_STORAGE_KEY),
            JSON.stringify(parsed),
          );
        } catch (e) {
          /* Non-fatal. */
        }
      }

      return parsed;
    }
  } catch (e) {
    /* Fall through to default starter. */
  }

  return [{ ...DEFAULT_STARTER, capturedAt: Date.now() }];
}

function saveCapturedList() {
  try {
    localStorage.setItem(
      nsKey(CAPTURED_STORAGE_KEY),
      JSON.stringify(capturedList),
    );
  } catch (e) {
    /* Storage unavailable — capture still works for this session. */
  }

  scheduleCloudPush();
}

function isCaptured(name) {
  return capturedList.some((p) => p.name === name);
}

function capturePokemon(pokemon) {
  if (isCaptured(pokemon.name)) {
    return false;
  }

  capturedList.push({
    name: pokemon.name,
    id: pokemon.id,
    capturedAt: Date.now(),
  });

  saveCapturedList();

  updateCapturedCountUI();

  return true;
}

/* ============================================================
   PURCHASE POKÉMON (buy with coins or gems, no battle required)
============================================================ */

function getPurchasePrice(data) {
  const statTotal = (data.stats || []).reduce(
    (sum, s) => sum + (s.base_stat || 0),
    0,
  );

  const coinPrice = Math.max(200, Math.round(statTotal * 4));

  const gemPrice = Math.max(5, Math.round(statTotal / 14));

  return { coinPrice, gemPrice };
}

function purchasePokemon(data, currency) {
  if (isCaptured(data.name)) {
    return;
  }

  const { coinPrice, gemPrice } = getPurchasePrice(data);

  if (currency === "gems") {
    if (gems < gemPrice) {
      showToast({
        icon: "💎",
        title: "Not enough gems",
        message:
          "You need " +
          gemPrice.toLocaleString() +
          " 💎 to buy " +
          formatDisplayName(data.name) +
          ".",
        tone: "error",
      });

      return;
    }

    gems -= gemPrice;
  } else {
    if (coins < coinPrice) {
      showToast({
        icon: "🥮",
        title: "Not enough coins",
        message:
          "You need " +
          coinPrice.toLocaleString() +
          " 🥮 to buy " +
          formatDisplayName(data.name) +
          ".",
        tone: "error",
      });

      return;
    }

    coins -= coinPrice;
  }

  capturePokemon(data);

  saveLeagueState();

  updateResourcesUI();

  sfxCapture();

  showToast({
    icon: "🛒",
    title: formatDisplayName(data.name) + " purchased!",
    message:
      "Added to your Pokédex for " +
      (currency === "gems"
        ? gemPrice.toLocaleString() + " 💎"
        : coinPrice.toLocaleString() + " 🥮") +
      ".",
    tone: "success",
    duration: 4000,
  });

  renderPokedexBody(data);

  applyRosterFilters().catch(() => {});
}

/* ============================================================
   CAPTURED COUNT (home screen)
============================================================ */

function updateCapturedCountUI() {
  const el = document.getElementById("captured-count");

  if (el) {
    el.textContent = capturedList.length;
  }
}

/* ============================================================
   SELECTED TEAM (persisted in localStorage)
============================================================ */

function loadSelectedTeamNames() {
  try {
    const raw = localStorage.getItem(nsKey(SELECTED_TEAM_KEY));

    return raw ? JSON.parse(raw) : [];
  } catch (e) {
    return [];
  }
}

function saveSelectedTeamNames() {
  try {
    localStorage.setItem(
      nsKey(SELECTED_TEAM_KEY),
      JSON.stringify([...teamSelection]),
    );
  } catch (e) {
    /* Ignore storage failures. */
  }

  scheduleCloudPush();
}

/* Player 2's team (local same-device 2-player mode) isn't tied to a
   signed-in account — it's whoever is sitting at the keyboard for
   this match — so it intentionally stays un-namespaced/shared. */

function loadSelectedTeamP2Names() {
  try {
    const raw = localStorage.getItem(SELECTED_TEAM_P2_KEY);

    return raw ? JSON.parse(raw) : [];
  } catch (e) {
    return [];
  }
}

function saveSelectedTeamP2Names() {
  try {
    localStorage.setItem(
      SELECTED_TEAM_P2_KEY,
      JSON.stringify([...p2TeamSelection]),
    );
  } catch (e) {
    /* Ignore storage failures. */
  }
}

function getPersistedSelectedName() {
  try {
    const stored = localStorage.getItem(nsKey(SELECTED_STORAGE_KEY));

    if (stored && capturedList.some((p) => p.name === stored)) {
      return stored;
    }
  } catch (e) {
    /* Ignore, fall through to starter. */
  }

  return capturedList[0].name;
}

function persistSelectedName(name) {
  try {
    localStorage.setItem(nsKey(SELECTED_STORAGE_KEY), name);
  } catch (e) {
    /* Non-fatal. */
  }

  scheduleCloudPush();
}

/* ============================================================
   BATTLE OUTCOME → CAPTURE
============================================================ */

function handleBattleFinished(
  playerWon,
  enemyPokemon,
  playerPokemonFinal,
  enemyTeam,
) {
  if (pendingLeagueMatch) {
    pendingLeagueMatch = false;

    applyLeagueResult(playerWon);
  }

  /* Capturing the loser's Pokémon only applies to 1-player (vs AI)
     matches. In local 2-player battles both teams belong to human
     trainers, so nobody's Pokémon get caught — Pokémon are only
     added to a Pokédex there through purchase. */

  if (
    !twoPlayerModeEnabled &&
    playerWon &&
    Array.isArray(enemyTeam) &&
    enemyTeam.length > 1
  ) {
    /* 6v6 win — every Pokémon on the beaten team gets caught. */

    const newlyCaught = enemyTeam.filter((p) => p && capturePokemon(p));

    if (newlyCaught.length) {
      setTimeout(() => {
        sfxCapture();

        showToast({
          icon: "🎉",
          title: "Gotcha!",
          message:
            newlyCaught.map((p) => formatDisplayName(p.name)).join(", ") +
            (newlyCaught.length > 1 ? " were" : " was") +
            " captured and added to your Pokédex!",
          tone: "success",
          duration: 4200,
        });
      }, 150);
    }
  } else if (!twoPlayerModeEnabled && playerWon && enemyPokemon) {
    const isNew = capturePokemon(enemyPokemon);

    if (isNew) {
      setTimeout(() => {
        sfxCapture();

        showToast({
          icon: "🎉",
          title: "Gotcha!",
          message:
            formatDisplayName(enemyPokemon.name) +
            " was captured and added to your Pokédex!",
          tone: "success",
        });
      }, 150);
    }
  }

  /* Line up a fresh wild opponent for the next match — but only in
     1-player mode. In 2-player mode the right-hand preview should
     keep reflecting Player 2's own chosen team, not a random reroll. */

  if (twoPlayerModeEnabled) {
    syncFighterPreviewForMode().catch(() => {});
  } else {
    rerollOpponent();
  }
}

/* ============================================================
   EVOLUTION (captured Pokémon evolve after time in your Pokédex)
============================================================ */

async function getNextEvolutionName(name) {
  if (Object.prototype.hasOwnProperty.call(evolutionChainCache, name)) {
    return evolutionChainCache[name];
  }

  try {
    const speciesRes = await fetch(
      "https://pokeapi.co/api/v2/pokemon-species/" + name,
    );

    if (!speciesRes.ok) {
      throw new Error("species request failed");
    }

    const species = await speciesRes.json();

    const chainRes = await fetch(species.evolution_chain.url);

    if (!chainRes.ok) {
      throw new Error("evolution chain request failed");
    }

    const chainData = await chainRes.json();

    const next = findNextEvolutionInChain(chainData.chain, name);

    evolutionChainCache[name] = next;

    return next;
  } catch (e) {
    evolutionChainCache[name] = null;

    return null;
  }
}

function findNextEvolutionInChain(node, name) {
  if (!node) {
    return null;
  }

  if (node.species && node.species.name === name) {
    const nextNode = node.evolves_to && node.evolves_to[0];

    return nextNode && nextNode.species ? nextNode.species.name : null;
  }

  for (const child of node.evolves_to || []) {
    const found = findNextEvolutionInChain(child, name);

    if (found !== null) {
      return found;
    }
  }

  return null;
}

async function checkEvolutions() {
  const now = Date.now();

  const due = capturedList.filter(
    (p) => p.capturedAt && now - p.capturedAt >= EVOLVE_AFTER_MS,
  );

  if (!due.length) {
    return;
  }

  const evolved = [];

  for (const p of due) {
    try {
      const nextName = await getNextEvolutionName(p.name);

      if (!nextName || nextName === p.name) {
        /* Final stage (or unknown) — stop re-checking every cycle. */

        p.capturedAt = now;

        continue;
      }

      const nextData = await fetchPokemon(nextName);

      const fromDisplay = formatDisplayName(p.name);

      const wasSelected = p.name === selectedName;

      const wasOnTeam = teamSelection.has(p.name);

      if (wasOnTeam) {
        teamSelection.delete(p.name);
        teamSelection.add(nextName);
        saveSelectedTeamNames();
      }

      p.name = nextName;
      p.id = nextData.id;
      p.capturedAt = now;

      if (wasSelected) {
        selectedName = nextName;

        persistSelectedName(nextName);

        selected = nextData;

        renderPokemon(selected, "player");
      }

      evolved.push(fromDisplay + " → " + formatDisplayName(nextName));
    } catch (e) {
      /* Skip on failure — it'll be retried on the next check. */
    }
  }

  saveCapturedList();

  updateCapturedCountUI();

  if (
    activeCategory &&
    !document.getElementById("roster-page").classList.contains("hidden")
  ) {
    applyRosterFilters();
  }

  if (evolved.length) {
    setTimeout(() => {
      sfxEvolve();

      showToast({
        icon: "✨",
        title: "Evolution!",
        message: evolved.join(" • "),
        tone: "success",
        duration: 4200,
      });
    }, 150);
  }
}

async function rerollOpponent() {
  try {
    const excludeId = selected ? selected.id : null;

    const fresh = await fetchPokemon(randomPokemonId(excludeId));

    opponent = fresh;

    renderPokemon(opponent, "enemy");
  } catch (e) {
    /* Keep the current opponent if the reroll fails. */
  }
}

/* Keep the home-screen fighter cards honest about who you're
   actually about to fight. In 1-player mode the right card is a
   wild AI opponent (rerollOpponent() above). In 2-player mode it
   should instead reflect Player 2's own hand-picked team, since
   nobody's Pokémon get auto-matched there — showing a random wild
   Pokémon while the battlefield actually runs Player 2's chosen
   squad was misleading. */

async function syncFighterPreviewForMode() {
  const playerLabel = document.getElementById("player-role-label");

  const enemyLabel = document.getElementById("enemy-role-label");

  if (twoPlayerModeEnabled) {
    if (playerLabel) playerLabel.textContent = "PLAYER 1";

    if (enemyLabel) enemyLabel.textContent = "PLAYER 2";

    const firstPick = [...p2TeamSelection][0];

    if (firstPick) {
      try {
        const data = await fetchPokemon(firstPick);

        renderPokemon(data, "enemy");
      } catch (e) {
        /* Keep whatever is currently shown if the fetch fails. */
      }
    }
  } else {
    if (playerLabel) playerLabel.textContent = "YOUR FIGHTER";

    if (enemyLabel) enemyLabel.textContent = "OPPONENT";

    await rerollOpponent();
  }
}

/* ============================================================
   FETCH POKEMON
============================================================ */

async function fetchPokemon(nameOrId) {
  const res = await fetch(API + nameOrId);

  if (!res.ok) {
    throw new Error("Pokémon request failed");
  }

  return res.json();
}

/* ============================================================
   LOAD FIGHTERS (home screen matchup)
============================================================ */

async function loadFighters() {
  const status = document.getElementById("api-status");

  try {
    selected = await fetchPokemon(selectedName);

    opponent = await fetchPokemon(randomPokemonId(selected.id));

    renderPokemon(selected, "player");

    renderPokemon(opponent, "enemy");

    status.textContent = "● LIVE • POKÉAPI CONNECTED";

    status.style.color = "#72e6a6";
  } catch (e) {
    status.textContent = "Offline demo data";

    status.style.color = "#ffbf69";

    selected = fallback(
      "Pikachu",
      "Electric",

      "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/other/official-artwork/25.png",
    );

    opponent = fallback(
      "Charizard",
      "Fire",

      "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/other/official-artwork/6.png",
    );

    renderPokemon(selected, "player");

    renderPokemon(opponent, "enemy");
  }
}

/* ============================================================
   RANDOM OPPONENT FROM THE FULL 1029-POKÉMON POOL
============================================================ */

function randomPokemonId(excludeId) {
  let id = Math.floor(Math.random() * POKEMON_COUNT) + 1;

  if (id === excludeId) {
    id = (id % POKEMON_COUNT) + 1;
  }

  return id;
}

/* ============================================================
   FALLBACK (offline demo data)
============================================================ */

/* Known National Dex numbers for the names fallback() gets called with.
   Falling back to a hardcoded id (previously always 6 for anything that
   wasn't Pikachu) made every non-Pikachu offline Pokémon collide on the
   same id, breaking dedupe/exclude checks that key off id. */
const FALLBACK_POKEMON_IDS = {
  pikachu: 25,
  charizard: 6,
  blastoise: 9,
  venusaur: 3,
  gengar: 94,
  dragonite: 149,
  alakazam: 65,
};

function fallback(name, type, img) {
  return {
    name,

    id: FALLBACK_POKEMON_IDS[name.toLowerCase()] || 6,

    types: [
      {
        type: {
          name: type.toLowerCase(),
        },
      },
    ],

    sprites: {
      other: {
        "official-artwork": {
          front_default: img,
        },
      },
    },

    stats: [
      { base_stat: 100 },
      { base_stat: 100 },
      { base_stat: 100 },
      { base_stat: 100 },
      { base_stat: 100 },
      { base_stat: 100 },
    ],

    abilities: [],

    moves: [],
  };
}

/* ============================================================
   DISPLAY POKEMON
============================================================ */

function renderPokemon(p, side) {
  const artwork =
    p.sprites?.other?.["official-artwork"]?.front_default ||
    p.sprites.front_default;

  document.getElementById(side + "-img").src = artwork;

  document.getElementById(side + "-name").textContent = p.name;

  document.getElementById(side + "-type").textContent =
    p.types[0].type.name.toUpperCase();

  const power = Math.round(p.stats.reduce((a, s) => a + s.base_stat, 0) / 5);

  document.getElementById(side + "-power").textContent = power;

  if (side === "player") {
    document.getElementById("p1-label").textContent = p.name;
  } else {
    document.getElementById("p2-label").textContent = p.name;
  }
}

/* ============================================================
   POKÉDEX / ROSTER (all 1029 Pokémon, browsable by type)
============================================================ */

async function ensureRosterList() {
  if (rosterList) {
    return rosterList;
  }

  if (rosterLoading) {
    return rosterLoading;
  }

  rosterLoading = fetch(
    "https://pokeapi.co/api/v2/pokemon?limit=" + POKEMON_COUNT,
  )
    .then((res) => {
      if (!res.ok) {
        throw new Error("Roster request failed");
      }

      return res.json();
    })
    .then((data) => {
      rosterList = data.results.map((entry, index) => {
        const match = entry.url.match(/\/pokemon\/(\d+)\//);

        return {
          name: entry.name,
          id: match ? Number(match[1]) : index + 1,
        };
      });

      return rosterList;
    })
    .finally(() => {
      rosterLoading = null;
    });

  return rosterLoading;
}

async function fetchTypeList(typeName) {
  if (typeListCache[typeName]) {
    return typeListCache[typeName];
  }

  const res = await fetch("https://pokeapi.co/api/v2/type/" + typeName);

  if (!res.ok) {
    throw new Error("Type request failed");
  }

  const data = await res.json();

  const list = data.pokemon
    .map((entry) => {
      const match = entry.pokemon.url.match(/\/pokemon\/(\d+)\//);

      return {
        name: entry.pokemon.name,
        id: match ? Number(match[1]) : null,
      };
    })
    .filter((p) => p.id);

  typeListCache[typeName] = list;

  return list;
}

async function getCategoryList(category) {
  if (category === "all") {
    return ensureRosterList();
  }

  if (category === "captured") {
    return capturedList.slice();
  }

  return fetchTypeList(category);
}

function artworkUrl(id) {
  return ARTWORK_BASE + id + ".png";
}

function spriteFallbackUrl(id) {
  return SPRITE_FALLBACK_BASE + id + ".png";
}

async function openRoster() {
  document.getElementById("home-page").classList.add("hidden");

  document.getElementById("roster-page").classList.remove("hidden");

  document.getElementById("roster-search").value = "";

  currentSearchQuery = "";

  setCategory("all");
}

function closeRoster() {
  document.getElementById("roster-page").classList.add("hidden");

  document.getElementById("home-page").classList.remove("hidden");

  closePokedex();
}

function setCategory(category) {
  activeCategory = category;

  document.querySelectorAll(".type-chip").forEach((chip) => {
    chip.classList.toggle("active", chip.dataset.type === category);
  });

  applyRosterFilters();
}

let rosterSearchTimer = null;

function handleRosterSearch(e) {
  const query = e.target.value.trim().toLowerCase();

  clearTimeout(rosterSearchTimer);

  rosterSearchTimer = setTimeout(() => {
    currentSearchQuery = query;

    applyRosterFilters();
  }, 120);
}

async function applyRosterFilters() {
  const count = document.getElementById("roster-count");

  const grid = document.getElementById("roster-grid");

  grid.innerHTML = "";

  count.textContent =
    activeCategory === "captured"
      ? "Loading your captured Pokémon…"
      : "Loading Pokémon…";

  try {
    let list = await getCategoryList(activeCategory);

    if (currentSearchQuery) {
      list = list.filter((p) => p.name.includes(currentSearchQuery));
    }

    count.textContent = buildCountLabel(list.length);

    renderRosterGrid(list, currentSearchQuery);
  } catch (e) {
    count.textContent = "Couldn't load this category — try again";

    renderRosterGrid(
      activeCategory === "all" ? OFFLINE_ROSTER : [],
      currentSearchQuery,
    );
  }
}

function buildCountLabel(n) {
  if (activeCategory === "captured") {
    return n + (n === 1 ? " POKÉMON CAPTURED" : " POKÉMON CAPTURED");
  }

  if (activeCategory === "all") {
    return n + " POKÉMON AVAILABLE";
  }

  return n + " " + activeCategory.toUpperCase() + "-TYPE POKÉMON";
}

function renderRosterGrid(list, query) {
  const grid = document.getElementById("roster-grid");

  grid.innerHTML = "";

  if (!list.length) {
    const empty = document.createElement("div");

    empty.className = "roster-empty";

    if (activeCategory === "captured") {
      empty.textContent =
        "You haven't captured any Pokémon yet — win a battle to catch your opponent!";
    } else {
      empty.textContent = query
        ? 'No Pokémon match "' + query + '".'
        : "No Pokémon found.";
    }

    grid.appendChild(empty);

    return;
  }

  const frag = document.createDocumentFragment();

  list.forEach((p) => {
    frag.appendChild(createRosterCard(p));
  });

  grid.appendChild(frag);
}

function createRosterCard(p) {
  const card = document.createElement("button");

  card.type = "button";

  const owned = isCaptured(p.name);

  card.className = "roster-card" + (p.name === selectedName ? " active" : "");

  const img = document.createElement("img");

  img.loading = "lazy";

  img.alt = p.name;

  img.src = artworkUrl(p.id);

  img.onerror = () => {
    img.onerror = null;

    img.src = spriteFallbackUrl(p.id);
  };

  const label = document.createElement("b");

  label.textContent = p.name.replace(/-/g, " ");

  const dexNumber = document.createElement("small");

  dexNumber.textContent = "#" + String(p.id).padStart(4, "0");

  card.append(img, label, dexNumber);

  if (owned) {
    const badge = document.createElement("span");

    badge.className = "captured-badge";

    badge.textContent = "⚡";

    card.appendChild(badge);
  } else {
    const buyBadge = document.createElement("span");

    buyBadge.className = "buy-badge";

    buyBadge.textContent = "🛒";

    buyBadge.title = "Available to buy with coins or gems";

    card.appendChild(buyBadge);
  }

  /*
  Clicking a Pokémon opens its Pokédex entry — it no longer
  selects it as your fighter directly. Fighter selection now
  only happens from inside the Pokédex, and only for Pokémon
  you've already captured.
  */

  card.onclick = () => openPokedex(p);

  return card;
}

/* ============================================================
   POKÉDEX DETAIL MODAL
============================================================ */

async function openPokedex(p) {
  const modal = document.getElementById("pokedex-modal");

  const body = document.getElementById("pokedex-body");

  modal.classList.remove("hidden");

  body.innerHTML = '<div class="roster-empty">Loading Pokédex entry…</div>';

  try {
    const data = await fetchPokemon(p.name);

    renderPokedexBody(data);
  } catch (e) {
    body.innerHTML =
      '<div class="roster-empty">Couldn\'t load this Pokémon. Try again.</div>';
  }
}

function closePokedex() {
  document.getElementById("pokedex-modal").classList.add("hidden");
}

function renderPokedexBody(data) {
  const body = document.getElementById("pokedex-body");

  const artwork =
    data.sprites?.other?.["official-artwork"]?.front_default ||
    data.sprites.front_default;

  const owned = isCaptured(data.name);

  const typesHtml = data.types
    .map(
      (t) =>
        '<span class="type-badge" data-type="' +
        t.type.name +
        '">' +
        t.type.name.toUpperCase() +
        "</span>",
    )
    .join("");

  const statsHtml = data.stats
    .map((s, i) => {
      const pct = Math.min(100, Math.round((s.base_stat / 255) * 100));

      return (
        '<div class="pokedex-stat-row">' +
        "<span>" +
        (STAT_LABELS[i] || s.stat.name) +
        "</span>" +
        '<div class="pokedex-stat-track">' +
        '<div class="pokedex-stat-fill" style="width:' +
        pct +
        '%"></div>' +
        "</div>" +
        "<span>" +
        s.base_stat +
        "</span>" +
        "</div>"
      );
    })
    .join("");

  const abilitiesText = (data.abilities || [])
    .map((a) => "<b>" + a.ability.name.replace(/-/g, " ") + "</b>")
    .join(", ");

  const statusHtml = owned
    ? '<div class="pokedex-capture-status owned">✓ CAPTURED — IN YOUR POKÉBALL</div>'
    : '<div class="pokedex-capture-status wild">WILD — WIN A BATTLE OR BUY IT BELOW TO CAPTURE IT</div>';

  const fightButtonHtml = owned
    ? '<button id="pokedex-fight-btn" class="pokedex-fight-btn">⚔ SET AS FIGHTER</button>'
    : "";

  let buyButtonsHtml = "";

  if (!owned) {
    const { coinPrice, gemPrice } = getPurchasePrice(data);

    const canAffordCoins = coins >= coinPrice;

    const canAffordGems = gems >= gemPrice;

    buyButtonsHtml =
      '<div class="pokedex-buy-row">' +
      '<button id="pokedex-buy-coins-btn" class="pokedex-buy-btn pokedex-buy-coins"' +
      (canAffordCoins ? "" : " disabled") +
      ">🥮 Buy for " +
      coinPrice.toLocaleString() +
      "</button>" +
      '<button id="pokedex-buy-gems-btn" class="pokedex-buy-btn pokedex-buy-gems"' +
      (canAffordGems ? "" : " disabled") +
      ">💎 Buy for " +
      gemPrice.toLocaleString() +
      "</button>" +
      "</div>";
  }

  body.innerHTML =
    '<div class="pokedex-top">' +
    '<img src="' +
    artwork +
    '" alt="' +
    data.name +
    '" />' +
    '<div class="pokedex-dex-no">#' +
    String(data.id).padStart(4, "0") +
    "</div>" +
    '<div class="pokedex-name">' +
    data.name.replace(/-/g, " ") +
    "</div>" +
    '<div class="pokedex-types">' +
    typesHtml +
    "</div>" +
    "</div>" +
    statusHtml +
    '<div class="pokedex-stats">' +
    statsHtml +
    "</div>" +
    (abilitiesText
      ? '<div class="pokedex-abilities">ABILITIES: ' + abilitiesText + "</div>"
      : "") +
    fightButtonHtml +
    buyButtonsHtml;

  if (owned) {
    document.getElementById("pokedex-fight-btn").onclick = () => {
      setFighterFromCaptured(data.name);
    };
  } else {
    const buyCoinsBtn = document.getElementById("pokedex-buy-coins-btn");

    if (buyCoinsBtn) {
      buyCoinsBtn.onclick = () => purchasePokemon(data, "coins");
    }

    const buyGemsBtn = document.getElementById("pokedex-buy-gems-btn");

    if (buyGemsBtn) {
      buyGemsBtn.onclick = () => purchasePokemon(data, "gems");
    }
  }
}

async function setFighterFromCaptured(name) {
  selectedName = name;

  persistSelectedName(name);

  closePokedex();

  closeRoster();

  const status = document.getElementById("api-status");

  status.textContent = "Loading " + name + "…";

  status.style.color = "#9fc1df";

  try {
    selected = await fetchPokemon(name);

    renderPokemon(selected, "player");

    status.textContent = "● LIVE • POKÉAPI CONNECTED";

    status.style.color = "#72e6a6";
  } catch (e) {
    status.textContent = "Couldn't load that Pokémon — try another";

    status.style.color = "#ff6d6d";
  }
}

/* ============================================================
   REAL MOVE DATA (fetched from PokéAPI per fighter)
============================================================

Each Pokémon's /pokemon/{name} response already lists every
move it can learn (names + URLs, no stats). To turn that into
a usable battle move we fetch a handful of the most promising
candidates' full move data (power, type, damage class) and
use the first genuine attacking move we find.

Visual presentation (projectile color/speed/range) still
comes from game.js's type-based TYPE_MOVES table, so the
move looks right even though its name/power is real.
============================================================ */

async function resolveBattleMove(pokemon) {
  const candidates = pickMoveCandidates(pokemon);

  /* Try a generous batch of candidates — many Pokémon's highest-level
     "signature" moves are actually status moves (stat boosts, buffs,
     etc.), not attacks, so stopping after just a few candidates left
     plenty of Pokémon without a real move and silently falling back
     to the shared generic type attack. Trying more candidates (and
     falling through level-up → other learn methods, see
     pickMoveCandidates below) makes it very likely every Pokémon
     finds a genuine attacking move of its own. */

  const tryLimit = Math.min(candidates.length, 20);

  for (let i = 0; i < tryLimit; i++) {
    try {
      const res = await fetch(candidates[i].url);

      if (!res.ok) {
        continue;
      }

      const data = await res.json();

      const isAttack =
        data.power && data.damage_class && data.damage_class.name !== "status";

      if (isAttack) {
        return buildMoveFromApi(data);
      }
    } catch (e) {
      /* Try the next candidate. */
    }
  }

  return null;
}

function pickMoveCandidates(pokemon) {
  const moves = Array.isArray(pokemon.moves) ? pokemon.moves : [];

  const levelUp = [];

  const seen = new Set();

  moves.forEach((m) => {
    const detail = (m.version_group_details || []).find(
      (d) => d.move_learn_method && d.move_learn_method.name === "level-up",
    );

    if (detail) {
      levelUp.push({
        name: m.move.name,
        url: m.move.url,
        level: detail.level_learned_at || 0,
      });

      seen.add(m.move.name);
    }
  });

  /* Prefer higher-level moves — usually a Pokémon's strongest, most signature attack. */

  levelUp.sort((a, b) => b.level - a.level);

  /* Everything else the Pokémon can learn (TM/tutor/egg moves), as
     further candidates in case none of its level-up moves turn out
     to deal damage. Combining both pools — instead of only falling
     back to this second pool when there are zero level-up moves —
     is what fixes Pokémon whose top level-up moves are all status
     effects (stat boosts, healing, etc.) from ending up with no real
     move and silently defaulting to the shared generic type attack. */

  const rest = moves
    .filter((m) => !seen.has(m.move.name))
    .map((m) => ({ name: m.move.name, url: m.move.url }));

  return levelUp.length ? levelUp.concat(rest) : rest;
}

function buildMoveFromApi(data) {
  const type = data.type ? data.type.name : "normal";

  const visuals = (window.TYPE_MOVES && window.TYPE_MOVES[type]) ||
    (window.TYPE_MOVES && window.TYPE_MOVES.normal) || {
      range: 220,
      projectile: true,
      color: "#f1f1df",
      speed: 11,
    };

  const damage = clampNumber(Math.round((data.power || 60) * 0.32), 12, 30);

  return {
    name: formatMoveName(data.name),
    type: type,
    damage: damage,
    range: visuals.range,
    projectile: visuals.projectile,
    color: visuals.color,
    speed: visuals.speed,
  };
}

function formatMoveName(name) {
  return String(name)
    .split("-")
    .map((part) => part.charAt(0).toUpperCase() + part.slice(1))
    .join(" ");
}

function formatDisplayName(name) {
  return String(name)
    .split("-")
    .map((part) => part.charAt(0).toUpperCase() + part.slice(1))
    .join(" ");
}

function clampNumber(value, min, max) {
  return Math.max(min, Math.min(max, value));
}

/* ============================================================
   TEAM SELECT MODAL
============================================================ */

function openTeamSelect() {
  /* In 2-player mode, Player 1 also gets to pick from the full
     Pokédex (same as Player 2), so there's always something to
     choose from. In 1-player mode, picking is still limited to
     captured Pokémon — skip straight to battle if none are caught
     yet, same as before. */

  if (!twoPlayerModeEnabled && !capturedList.length) {
    startBattle();

    return;
  }

  const search = document.getElementById("team-select-search");

  const searchWrap = document.getElementById("team-select-search-wrap");

  const hint = document.getElementById("team-select-hint");

  teamSelectQuery = "";

  if (search) {
    search.value = "";
  }

  if (searchWrap) {
    searchWrap.classList.toggle("hidden", !twoPlayerModeEnabled);
  }

  if (hint) {
    hint.textContent = twoPlayerModeEnabled
      ? "Pick up to 6 Pokémon from the full Pokédex to fight with. Leave slots empty and they'll be auto-filled with wild Pokémon."
      : "Pick up to 6 captured Pokémon to fight with. Leave slots empty and they'll be auto-filled with wild Pokémon.";
  }

  renderTeamSelectGrid();

  document.getElementById("team-select-modal").classList.remove("hidden");
}

function closeTeamSelect() {
  document.getElementById("team-select-modal").classList.add("hidden");
}

function handleTeamSelectSearch(e) {
  const query = e.target.value.trim().toLowerCase();

  clearTimeout(teamSelectSearchTimer);

  teamSelectSearchTimer = setTimeout(() => {
    teamSelectQuery = query;

    renderTeamSelectGrid();
  }, 120);
}

async function renderTeamSelectGrid() {
  const grid = document.getElementById("team-select-grid");

  if (twoPlayerModeEnabled) {
    await renderPokedexPickerGrid(
      grid,
      teamSelectQuery,
      teamSelection,
      toggleTeamPick,
    );
  } else {
    renderCapturedPickerGrid(grid);
  }

  updateTeamSelectCount();
}

function renderCapturedPickerGrid(grid) {
  grid.innerHTML = capturedList
    .map((p) => {
      const isSelected = teamSelection.has(p.name);

      const artwork = artworkUrl(p.id);

      return (
        '<div class="roster-card team-pick-card' +
        (isSelected ? " active" : "") +
        '" data-name="' +
        p.name +
        '">' +
        (isSelected ? '<span class="captured-badge">✓</span>' : "") +
        '<img src="' +
        artwork +
        '" alt="' +
        p.name +
        '" />' +
        "<b>" +
        formatDisplayName(p.name) +
        "</b>" +
        "</div>"
      );
    })
    .join("");

  grid.querySelectorAll(".team-pick-card").forEach((card) => {
    card.onclick = () => toggleTeamPick(card.dataset.name);
  });
}

/* ============================================================
   SHARED FULL-POKÉDEX PICKER GRID
   (used by both Player 1's and Player 2's team-select modals
   in 2-player mode, where neither is limited to a captured list)
============================================================ */

async function renderPokedexPickerGrid(grid, query, selectionSet, onToggle) {
  if (!grid) {
    return;
  }

  grid.innerHTML = '<div class="roster-empty">Loading Pokédex…</div>';

  let list;

  try {
    list = await ensureRosterList();
  } catch (e) {
    list = OFFLINE_ROSTER;
  }

  if (query) {
    list = list.filter((p) => p.name.includes(query));
  }

  if (!list.length) {
    grid.innerHTML =
      '<div class="roster-empty">No Pokémon match "' + query + '".</div>';

    return;
  }

  grid.innerHTML = list
    .map((p) => {
      const isSelected = selectionSet.has(p.name);

      const artwork = artworkUrl(p.id);

      return (
        '<div class="roster-card team-pick-card' +
        (isSelected ? " active" : "") +
        '" data-name="' +
        p.name +
        '">' +
        (isSelected ? '<span class="captured-badge">✓</span>' : "") +
        '<img src="' +
        artwork +
        '" alt="' +
        p.name +
        '" />' +
        "<b>" +
        formatDisplayName(p.name) +
        "</b>" +
        "</div>"
      );
    })
    .join("");

  grid.querySelectorAll(".team-pick-card").forEach((card) => {
    card.onclick = () => onToggle(card.dataset.name);
  });
}

function toggleTeamPick(name) {
  if (teamSelection.has(name)) {
    teamSelection.delete(name);
  } else {
    if (teamSelection.size >= TEAM_SIZE) {
      return;
    }

    teamSelection.add(name);
  }

  renderTeamSelectGrid();
}

function updateTeamSelectCount() {
  const el = document.getElementById("team-select-count");

  if (el) {
    el.textContent = teamSelection.size + "/" + TEAM_SIZE + " SELECTED";
  }
}

/* ============================================================
   TEAM SELECT MODAL — PLAYER 2 (local 2-player mode)

   P2 has no captured Pokémon of their own in this single-device
   app, so they pick their squad from the full Pokédex instead,
   with a search box to make browsing 1000+ Pokémon practical.
============================================================ */

let teamSelectP2Query = "";

let teamSelectP2SearchTimer = null;

function openTeamSelectP2() {
  const search = document.getElementById("team-select-p2-search");

  if (search) {
    search.value = "";
  }

  teamSelectP2Query = "";

  renderTeamSelectP2Grid();

  document.getElementById("team-select-p2-modal").classList.remove("hidden");
}

function closeTeamSelectP2() {
  document.getElementById("team-select-p2-modal").classList.add("hidden");
}

function handleTeamSelectP2Search(e) {
  const query = e.target.value.trim().toLowerCase();

  clearTimeout(teamSelectP2SearchTimer);

  teamSelectP2SearchTimer = setTimeout(() => {
    teamSelectP2Query = query;

    renderTeamSelectP2Grid();
  }, 120);
}

async function renderTeamSelectP2Grid() {
  const grid = document.getElementById("team-select-p2-grid");

  if (!grid) {
    return;
  }

  grid.innerHTML = '<div class="roster-empty">Loading Pokédex…</div>';

  let list;

  try {
    list = await ensureRosterList();
  } catch (e) {
    list = OFFLINE_ROSTER;
  }

  if (teamSelectP2Query) {
    list = list.filter((p) => p.name.includes(teamSelectP2Query));
  }

  if (!list.length) {
    grid.innerHTML =
      '<div class="roster-empty">No Pokémon match "' +
      teamSelectP2Query +
      '".</div>';

    updateTeamSelectP2Count();

    return;
  }

  grid.innerHTML = list
    .map((p) => {
      const isSelected = p2TeamSelection.has(p.name);

      return (
        '<div class="roster-card team-pick-card' +
        (isSelected ? " active" : "") +
        '" data-name="' +
        p.name +
        '">' +
        (isSelected ? '<span class="captured-badge">✓</span>' : "") +
        '<img loading="lazy" src="' +
        artworkUrl(p.id) +
        '" alt="' +
        p.name +
        '" />' +
        "<b>" +
        formatDisplayName(p.name) +
        "</b>" +
        "</div>"
      );
    })
    .join("");

  grid.querySelectorAll(".team-pick-card").forEach((card) => {
    card.onclick = () => toggleTeamPickP2(card.dataset.name);
  });

  updateTeamSelectP2Count();
}

function toggleTeamPickP2(name) {
  if (p2TeamSelection.has(name)) {
    p2TeamSelection.delete(name);
  } else {
    if (p2TeamSelection.size >= TEAM_SIZE) {
      return;
    }

    p2TeamSelection.add(name);
  }

  renderTeamSelectP2Grid();
}

function updateTeamSelectP2Count() {
  const el = document.getElementById("team-select-p2-count");

  if (el) {
    el.textContent = p2TeamSelection.size + "/" + TEAM_SIZE + " SELECTED";
  }
}

/* ============================================================
   TEAM BUILDING (6v6)
============================================================ */

const TEAM_SIZE = 6;

/*
Your team: every Pokémon you've captured (up to 6), always
including your current starter, topped up with fresh wild
Pokémon so every match is a full 6v6 even early on.
*/

async function buildPlayerTeam() {
  /* In 1-player mode, selections only ever come from the captured
     grid, so this is already a no-op guard there. In 2-player mode
     Player 1 can pick from the full Pokédex (same as Player 2), so
     picks don't need to exist in capturedList — fetchPokemon()
     below already validates each name and drops anything invalid. */

  const chosenNames = twoPlayerModeEnabled
    ? [...teamSelection]
    : [...teamSelection].filter((n) => capturedList.some((p) => p.name === n));

  /* An explicit selection is used as-is; otherwise fall back to
     every captured Pokémon, same as before team select existed. */

  const sourceNames = chosenNames.length
    ? chosenNames
    : [...new Set(capturedList.map((p) => p.name))];

  const sourceFetched = (
    await Promise.all(sourceNames.map((n) => fetchPokemon(n).catch(() => null)))
  ).filter(Boolean);

  const team = [];
  const usedIds = new Set();

  /* No selection and nothing captured yet — always include the
     home-screen starter so the battle isn't empty. */

  if (!chosenNames.length && selected) {
    team.push(selected);
    usedIds.add(selected.id);
  }

  for (const p of sourceFetched) {
    if (team.length >= TEAM_SIZE) break;
    if (usedIds.has(p.id)) continue;
    team.push(p);
    usedIds.add(p.id);
  }

  let attempts = 0;

  while (team.length < TEAM_SIZE && attempts < 20) {
    attempts++;

    const id = randomPokemonId();

    if (usedIds.has(id)) continue;

    try {
      const p = await fetchPokemon(id);
      usedIds.add(id);
      team.push(p);
    } catch (e) {
      /* Skip a failed fetch and try another id. */
    }
  }

  return team;
}

/*
Opponent team: 6 distinct wild Pokémon, none overlapping your team.
*/

async function buildOpponentTeam(excludeIds, chosenNames) {
  const team = [];

  /* ownIds tracks species already placed on THIS (opponent) team, so
     we never put the same Pokémon on the opponent's team twice. It
     deliberately does NOT start from excludeIds (the player's team)
     — an explicit pick (Player 2's own choice, or the Pokémon shown
     as the home-screen opponent) should always make it into the
     battle, even if the player happens to be using the same species.
     Only the random wild auto-fill below avoids mirroring the
     player's team, to keep those filler match-ups varied. */

  const ownIds = new Set();

  /* Player 2 (local 2-player mode) may have hand-picked some or all
     of these from the full Pokédex — use those first. In 1-player
     mode this instead carries the single wild Pokémon shown as the
     "OPPONENT" preview on the home screen, so the fighter you see
     there is guaranteed to actually show up in the battle. */

  if (Array.isArray(chosenNames) && chosenNames.length) {
    const chosenFetched = (
      await Promise.all(
        chosenNames.map((n) => fetchPokemon(n).catch(() => null)),
      )
    ).filter(Boolean);

    for (const p of chosenFetched) {
      if (team.length >= TEAM_SIZE) break;
      if (ownIds.has(p.id)) continue;
      team.push(p);
      ownIds.add(p.id);
    }
  }

  /* Auto-fill any remaining slots with wild Pokémon — these avoid
     both the player's team and whatever explicit picks already made
     it onto this team, so filler matches stay varied. */

  const fillExcludeIds = new Set([...(excludeIds || []), ...ownIds]);

  let attempts = 0;

  while (team.length < TEAM_SIZE && attempts < 30) {
    attempts++;

    const id = randomPokemonId();

    if (fillExcludeIds.has(id)) continue;

    try {
      const p = await fetchPokemon(id);
      fillExcludeIds.add(id);
      team.push(p);
    } catch (e) {
      /* Skip a failed fetch and try another id. */
    }
  }

  /* Offline fallback so a battle can still start if PokéAPI is unreachable.
     Cycle through a small roster of distinct starters instead of pushing
     the same `opponent` object reference six times — reusing one object
     across every slot made all six "different" Pokémon actually be the
     exact same object (same name, sprite, and even shared mutable state
     like hp/fainted, since they all pointed at one thing in memory). */

  const OFFLINE_FALLBACK_ROSTER = [
    [
      "Charizard",
      "Fire",
      "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/other/official-artwork/6.png",
    ],
    [
      "Blastoise",
      "Water",
      "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/other/official-artwork/9.png",
    ],
    [
      "Venusaur",
      "Grass",
      "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/other/official-artwork/3.png",
    ],
    [
      "Gengar",
      "Ghost",
      "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/other/official-artwork/94.png",
    ],
    [
      "Dragonite",
      "Dragon",
      "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/other/official-artwork/149.png",
    ],
    [
      "Alakazam",
      "Psychic",
      "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/other/official-artwork/65.png",
    ],
  ];

  let fallbackIndex = 0;

  while (team.length < TEAM_SIZE) {
    const [name, type, img] =
      OFFLINE_FALLBACK_ROSTER[fallbackIndex % OFFLINE_FALLBACK_ROSTER.length];

    fallbackIndex++;

    team.push(fallback(name, type, img));
  }

  return team;
}

/* ============================================================
   START BATTLE
============================================================ */

async function startBattle() {
  document.getElementById("home-page").classList.add("hidden");

  document.getElementById("battlefield-page").classList.remove("hidden");

  resetBattleUI();

  const transcript = document.getElementById("controls-transcript");

  if (transcript) {
    transcript.textContent = "Assembling your 6v6 teams…";
  }

  const playerTeam = await buildPlayerTeam();

  const p2Names = twoPlayerModeEnabled
    ? [...p2TeamSelection]
    : opponent
      ? [opponent.name]
      : null;

  const enemyTeam = await buildOpponentTeam(
    playerTeam.map((p) => p.id),
    p2Names,
  );

  if (transcript) {
    transcript.textContent = "Loading signature moves…";
  }

  /*
  Give every Pokémon on both teams its own real, PokéAPI-derived
  attack instead of falling back to a shared generic type move —
  otherwise most Pokémon (anything outside the small hand-picked
  list in game.js) end up all throwing the same "special ability".
  */

  await Promise.all(
    [...playerTeam, ...enemyTeam].map(async (p) => {
      try {
        const move = await resolveBattleMove(p);

        if (move) {
          p.realMove = move;
        }
      } catch (e) {
        /* Keep the type-based fallback if a real move can't be found. */
      }
    }),
  );

  initTeamBattleEngine(playerTeam, enemyTeam, twoPlayerModeEnabled);
}

/* ============================================================
   RESET HP
============================================================ */

function resetBattleUI() {
  document.getElementById("p1-hp").style.width = "100%";

  document.getElementById("p2-hp").style.width = "100%";
}
