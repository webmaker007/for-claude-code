POKÉMON FIGHTER — WINDOWS DESKTOP APP
======================================

This folder is an Electron project that wraps your existing game into a
real Windows .exe (a proper installer with a Start Menu entry, desktop
shortcut, and taskbar icon — not the browser PWA).

HOW TO BUILD THE .EXE (on your Windows PC)
-------------------------------------------
1. Install Node.js if you don't have it: https://nodejs.org (LTS version)
2. Open Command Prompt / PowerShell in this folder.
3. Run:
      npm install
4. Run:
      npm run dist

That's it. electron-builder will download what it needs, build the app,
and drop an installer at:

      dist\Pokemon Fighter Setup 1.0.0.exe

Double-click that installer to install the game like any normal Windows
app. It creates Start Menu + Desktop shortcuts automatically.

WANT TO TEST IT FIRST WITHOUT BUILDING AN INSTALLER?
-------------------------------------------------------
After `npm install`, just run:
      npm start

This opens the game in its own window immediately, no packaging step —
useful for a quick check before you build the real installer.

NOTES
-----
- The first `npm install` will download Electron itself (~100-200 MB),
  so it needs a real internet connection and may take a couple of
  minutes.
- The install/download button that appears in the browser version of
  the game (the green "Download" button) is unrelated to this — that's
  for browser-based PWA installs. This Electron app is a separate,
  fully native alternative if you'd rather ship a normal .exe.
- If Windows SmartScreen warns about an "unrecognized app" when you run
  the installer, that's just because it isn't code-signed (a paid
  certificate is required to avoid this) — click "More info" → "Run
  anyway". This is normal for unsigned indie apps and not a sign of a
  problem with the build.
