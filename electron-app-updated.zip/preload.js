const { contextBridge, ipcRenderer } = require("electron");

/* Exposes a minimal, safe API to the renderer (no direct Node/Electron
   access is given to the page itself — contextIsolation stays on).
   Right now this is just the desktop Google Sign-In flow: the renderer
   calls window.electronAPI.signInWithGoogle() and gets back either
   { ok: true, idToken } or { ok: false, error }. See main.js for what
   actually happens (opens the system browser, runs a local loopback
   server, exchanges the code for tokens). */

contextBridge.exposeInMainWorld("electronAPI", {
  isElectron: true,
  signInWithGoogle: () => ipcRenderer.invoke("google-sign-in"),
});
