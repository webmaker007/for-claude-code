"use strict";

/*
============================================================
 POKÉMON FIGHTER
 GAME.JS
 UNIVERSAL BATTLE ENGINE
============================================================

 FEATURES

 - Works with Pokémon loaded dynamically from PokéAPI
 - Uses exact Pokémon selected on Home
 - No hard-coded Gengar
 - Pokémon-specific attacks
 - Pokémon-specific move names
 - Fast P2 AI
 - Player and enemy always face each other
 - Jump
 - Move
 - Dodge
 - Block
 - Attack
 - Projectiles
 - Particles
 - VFX
 - Hit effects
 - Attack animation
 - Idle animation
 - Jump animation
 - Damage numbers
 - Combo
 - Screen shake
 - One requestAnimationFrame loop
============================================================
*/

/* ============================================================
   CONFIG
============================================================ */

const GAME = {
  width: 1200,
  height: 650,

  ground: 505,

  gravity: 1.18,
  jumpPower: -19,

  playerSpeed: 6.2,
  enemySpeed: 5.7,

  maxHP: 100,

  minDistance: 115,

  attackCooldown: 430,
  attackDuration: 270,
  attackHitFrame: 155,

  maxParticles: 60,
  maxProjectiles: 10,
  maxEffects: 30,
  maxFloatingTexts: 10,

  playerStartX: 300,
  enemyStartX: 900,
};

/* ============================================================
   TYPE MOVE DATA
============================================================ */

const TYPE_MOVES = {
  normal: {
    name: "Quick Attack",
    type: "normal",
    damage: 16,
    range: 260,
    projectile: true,
    color: "#f1f1df",
    speed: 14,
  },

  fire: {
    name: "Flamethrower",
    type: "fire",
    damage: 20,
    range: 270,
    projectile: true,
    color: "#ff6a22",
    speed: 12,
  },

  water: {
    name: "Water Pulse",
    type: "water",
    damage: 18,
    range: 280,
    projectile: true,
    color: "#42b9ff",
    speed: 13,
  },

  electric: {
    name: "Thunderbolt",
    type: "electric",
    damage: 20,
    range: 300,
    projectile: true,
    color: "#ffe34a",
    speed: 15,
  },

  grass: {
    name: "Vine Whip",
    type: "grass",
    damage: 18,
    range: 260,
    projectile: true,
    color: "#62db65",
    speed: 12,
  },

  ice: {
    name: "Ice Beam",
    type: "ice",
    damage: 21,
    range: 330,
    projectile: true,
    color: "#8eeaff",
    speed: 17,
  },

  fighting: {
    name: "Aura Strike",
    type: "fighting",
    damage: 22,
    range: 250,
    projectile: true,
    color: "#62b7ff",
    speed: 13,
  },

  poison: {
    name: "Poison Burst",
    type: "poison",
    damage: 18,
    range: 270,
    projectile: true,
    color: "#bd68e8",
    speed: 11,
  },

  ground: {
    name: "Earth Power",
    type: "ground",
    damage: 21,
    range: 260,
    projectile: true,
    color: "#c99b61",
    speed: 10,
  },

  flying: {
    name: "Air Slash",
    type: "flying",
    damage: 18,
    range: 290,
    projectile: true,
    color: "#b7e4ff",
    speed: 14,
  },

  psychic: {
    name: "Psychic",
    type: "psychic",
    damage: 22,
    range: 310,
    projectile: true,
    color: "#ff78d5",
    speed: 12,
  },

  bug: {
    name: "Bug Buzz",
    type: "bug",
    damage: 18,
    range: 290,
    projectile: true,
    color: "#a9d63d",
    speed: 13,
  },

  rock: {
    name: "Rock Throw",
    type: "rock",
    damage: 21,
    range: 290,
    projectile: true,
    color: "#b9a27d",
    speed: 9,
  },

  ghost: {
    name: "Shadow Ball",
    type: "ghost",
    damage: 21,
    range: 310,
    projectile: true,
    color: "#a75bea",
    speed: 11,
  },

  dragon: {
    name: "Dragon Pulse",
    type: "dragon",
    damage: 23,
    range: 320,
    projectile: true,
    color: "#7786ff",
    speed: 13,
  },

  dark: {
    name: "Dark Pulse",
    type: "dark",
    damage: 22,
    range: 300,
    projectile: true,
    color: "#77667c",
    speed: 12,
  },

  steel: {
    name: "Metal Burst",
    type: "steel",
    damage: 21,
    range: 260,
    projectile: true,
    color: "#b8c8d8",
    speed: 12,
  },

  fairy: {
    name: "Fairy Wind",
    type: "fairy",
    damage: 20,
    range: 290,
    projectile: true,
    color: "#ff9dd7",
    speed: 12,
  },
};

/* ============================================================
   POKÉMON MOVE NAMES
============================================================ */

const POKEMON_MOVE_NAMES = {
  pikachu: "Thunderbolt",
  raichu: "Thunderbolt",

  charizard: "Flamethrower",
  charmeleon: "Flamethrower",
  charmander: "Ember",

  squirtle: "Water Pulse",
  wartortle: "Water Pulse",
  blastoise: "Hydro Pump",

  bulbasaur: "Vine Whip",
  ivysaur: "Vine Whip",
  venusaur: "Solar Beam",

  gengar: "Shadow Ball",

  mewtwo: "Psystrike",
  mew: "Psychic",

  lucario: "Aura Sphere",

  greninja: "Water Shuriken",

  gyarados: "Hydro Pump",

  dragonite: "Dragon Pulse",

  garchomp: "Dragon Claw",

  eevee: "Swift",

  jolteon: "Thunderbolt",

  flareon: "Flamethrower",

  vaporeon: "Water Pulse",

  sylveon: "Fairy Wind",

  cinderace: "Pyro Ball",

  incineroar: "Darkest Lariat",

  dragapult: "Shadow Ball",

  annihilape: "Rage Fist",
};

/* ============================================================
   ARTWORK ORIENTATION OVERRIDES
============================================================

Most official-artwork sprites face LEFT by default, which is
what the mirroring math in drawPokemonImage() assumes.

A handful of Pokémon are drawn in action poses that face
RIGHT instead (e.g. Blaziken's kicking pose). List those
here so they get mirrored the opposite way.

Add more names to this list as you spot them facing the
wrong way in-battle.
============================================================ */

const ARTWORK_FACES_RIGHT = new Set(["blaziken"]);

function getArtworkNaturalFacing(pokemon) {
  const name = cleanPokemonName(pokemon && pokemon.name);

  /*
  1  = artwork naturally faces RIGHT
  -1 = artwork naturally faces LEFT (default)
  */

  return ARTWORK_FACES_RIGHT.has(name) ? 1 : -1;
}

/* ============================================================
   MOVE TYPE OVERRIDES
============================================================ */

const MOVE_TYPE_OVERRIDE = {
  Thunderbolt: "electric",
  Flamethrower: "fire",
  Ember: "fire",

  HydroPump: "water",
  "Hydro Pump": "water",

  "Water Pulse": "water",
  "Water Shuriken": "water",

  "Vine Whip": "grass",
  "Solar Beam": "grass",

  "Shadow Ball": "ghost",

  Psystrike: "psychic",
  Psychic: "psychic",

  "Aura Sphere": "fighting",

  "Dragon Pulse": "dragon",
  "Dragon Claw": "dragon",

  Swift: "normal",

  "Fairy Wind": "fairy",

  "Pyro Ball": "fire",

  "Darkest Lariat": "dark",

  "Rage Fist": "ghost",
};

/* ============================================================
   STATE
============================================================ */

let playerPokemon = {
  id: 25,
  name: "pikachu",
  types: [],
};

let enemyPokemon = {
  id: 6,
  name: "charizard",
  types: [],
};

let playerMove = null;
let enemyMove = null;

/*
TEAM BATTLE STATE (6v6)

playerTeam / enemyTeam hold up to 6 normalized Pokémon each.
playerTeam[playerTeamIndex] / enemyTeam[enemyTeamIndex] is always
the Pokémon currently loaded into playerPokemon / enemyPokemon.
A single-Pokémon battle is just a team of length 1, so all the
old 1v1 code paths keep working unchanged.
*/

let playerTeam = [];
let enemyTeam = [];
let playerTeamIndex = 0;
let enemyTeamIndex = 0;

let canvas = null;
let ctx = null;

let gameRunning = false;
let animationId = null;
let lastTime = 0;

let battleEnded = false;
let screenShake = 0;

let playerImage = null;
let enemyImage = null;

const imageCache = new Map();

const keys = Object.create(null);

/* Local 2-player mode: when true, the arrow-key side is driven by a
   second human on the same keyboard instead of the AI. */
let twoPlayerMode = false;

let particles = [];
let projectiles = [];
let effects = [];
let floatingTexts = [];

/* ============================================================
   FIGHTER CREATOR
============================================================ */

function createFighter(x, facing) {
  return {
    x: x,
    y: GAME.ground,

    vx: 0,
    vy: 0,

    hp: GAME.maxHP,

    /*
    IMPORTANT

    1 = face RIGHT
    -1 = face LEFT
    */

    facing: facing,

    jumping: false,

    attacking: false,
    blocking: false,
    dodging: false,
    invulnerable: false,

    attackTimer: 0,
    attackCooldown: 0,
    attackHit: false,

    hitTimer: 0,

    dodgeTimer: 0,

    combo: 0,
    comboTimer: 0,

    animationTime: 0,

    hitFlash: 0,

    aiThink: 0,
    aiAttackDelay: 0,
    aiBlockTimer: 0,

    /* Brief invulnerability window after a team switch-in. */
    swapTimer: 0,

    /* Cooldown that blocks switching again right after a switch. */
    switchLock: 0,
  };
}

/* ============================================================
   FIGHTERS
============================================================ */

const player = createFighter(GAME.playerStartX, 1);

const enemy = createFighter(GAME.enemyStartX, -1);

/* ============================================================
   UTILITIES
============================================================ */

/* ============================================================
   REAL-WORLD SIZE SCALE

   PokéAPI reports height in decimeters. We scale each Pokémon's
   on-screen size against a "reference" height so a Diglett looks
   tiny and an Onix looks enormous — always relative to whoever
   it's fighting, so the pair reads correctly no matter who else
   is on screen.
============================================================ */

const SIZE_REFERENCE_HEIGHT = 12; // ~1.2m, a roughly "average" Pokémon

function getSizeScale(pokemon) {
  const h =
    pokemon && typeof pokemon.height === "number" && pokemon.height > 0
      ? pokemon.height
      : SIZE_REFERENCE_HEIGHT;

  /* Square-root curve keeps huge height gaps (Wailord vs Joltik)
     dramatic but still playable — a straight linear scale would
     make tiny Pokémon nearly invisible and giants fill the screen. */

  const scale = Math.sqrt(h / SIZE_REFERENCE_HEIGHT);

  return clamp(scale, 0.52, 1.95);
}

function clamp(value, min, max) {
  return Math.max(min, Math.min(max, value));
}

function capitalize(value) {
  if (!value) {
    return "";
  }

  return (
    String(value).charAt(0).toUpperCase() + String(value).slice(1).toLowerCase()
  );
}

function cleanPokemonName(name) {
  return String(name || "")
    .toLowerCase()
    .replace(/[^a-z0-9]/g, "");
}

function formatPokemonName(name) {
  if (!name) {
    return "Pokémon";
  }

  return String(name)
    .split("-")
    .map(function (part) {
      return capitalize(part);
    })
    .join(" ");
}

/* ============================================================
   NORMALIZE POKÉMON
============================================================ */

function normalizePokemon(value) {
  if (!value) {
    return null;
  }

  if (typeof value === "number") {
    return {
      id: value,
      name: "pokemon-" + value,
      types: [],
    };
  }

  if (typeof value === "string") {
    return {
      id: null,
      name: value,
      types: [],
    };
  }

  if (typeof value === "object") {
    return {
      id: Number(value.id) || null,

      name: value.name || "pokemon",

      types: Array.isArray(value.types) ? value.types : [],

      moves: Array.isArray(value.moves) ? value.moves : [],

      stats: Array.isArray(value.stats) ? value.stats : [],

      sprites: value.sprites || null,

      /* Real-world height in decimeters, straight from PokéAPI.
         Used to draw each Pokémon at its size relative to its
         opponent instead of everyone being the same size. */
      height: Number(value.height) || null,

      /* A real, PokéAPI-derived signature move (fetched by
         app.js's resolveBattleMove), when available. getMove()
         prefers this over the generic type-based fallback so
         every Pokémon — not just the ~30 in POKEMON_MOVE_NAMES —
         fights with its own real attack. */
      realMove: value.realMove || null,
    };
  }

  return null;
}

/* ============================================================
   GET POKÉMON TYPE
============================================================ */

function getPokemonType(pokemon) {
  if (pokemon && Array.isArray(pokemon.types) && pokemon.types.length) {
    const first = pokemon.types[0];

    if (first && first.type && first.type.name) {
      return first.type.name;
    }

    if (first && first.name) {
      return first.name;
    }
  }

  return "normal";
}

/* ============================================================
   GET MOVE
============================================================ */

function getMove(pokemon) {
  /*
  Prefer a real move fetched from PokéAPI (app.js's
  resolveBattleMove) — this is what makes every Pokémon use its
  own signature attack instead of a shared generic type move.
  */

  if (pokemon && pokemon.realMove) {
    return { ...pokemon.realMove };
  }

  const name = cleanPokemonName(pokemon && pokemon.name);

  const overrideName = POKEMON_MOVE_NAMES[name];

  if (overrideName) {
    const normalizedOverride = overrideName.toLowerCase();

    const moveKey = Object.keys(TYPE_MOVES).find(function (key) {
      return TYPE_MOVES[key].name.toLowerCase() === normalizedOverride;
    });

    if (moveKey) {
      return {
        ...TYPE_MOVES[moveKey],
      };
    }

    const type = MOVE_TYPE_OVERRIDE[overrideName] || getPokemonType(pokemon);

    return {
      ...(TYPE_MOVES[type] || TYPE_MOVES.normal),

      name: overrideName,
      type: type,
    };
  }

  const type = getPokemonType(pokemon);

  return {
    ...(TYPE_MOVES[type] || TYPE_MOVES.normal),
  };
}

/* ============================================================
   CREATE CANVAS
============================================================ */

function createCanvas() {
  const container = document.getElementById("game-container");

  if (!container) {
    console.error("#game-container not found.");

    return false;
  }

  container.style.position = "absolute";
  container.style.inset = "0";
  container.style.width = "100%";
  container.style.height = "100%";
  container.style.overflow = "hidden";

  if (canvas && canvas.parentElement === container) {
    return true;
  }

  canvas = document.createElement("canvas");

  canvas.id = "pokemon-battle-canvas";

  canvas.width = GAME.width;
  canvas.height = GAME.height;

  canvas.style.position = "absolute";
  canvas.style.left = "0";
  canvas.style.top = "0";

  canvas.style.width = "100%";
  canvas.style.height = "100%";

  canvas.style.display = "block";

  canvas.style.zIndex = "1";

  canvas.style.pointerEvents = "none";

  container.appendChild(canvas);

  ctx = canvas.getContext("2d", {
    alpha: false,
    desynchronized: true,
  });

  if (!ctx) {
    return false;
  }

  return true;
}

/* ============================================================
   IMAGE LOADER
============================================================ */

function loadPokemonImage(pokemon) {
  if (!pokemon) {
    return Promise.resolve(null);
  }

  const id = Number(pokemon.id);

  if (!id) {
    return Promise.resolve(null);
  }

  if (imageCache.has(id)) {
    return imageCache.get(id);
  }

  const promise = new Promise(function (resolve) {
    const image = new Image();

    image.crossOrigin = "anonymous";

    let fallbackUsed = false;

    image.onload = function () {
      resolve(image);
    };

    image.onerror = function () {
      if (!fallbackUsed) {
        fallbackUsed = true;

        image.src =
          "https://raw.githubusercontent.com/" +
          "PokeAPI/sprites/master/sprites/pokemon/" +
          id +
          ".png";

        return;
      }

      resolve(null);
    };

    image.src =
      "https://raw.githubusercontent.com/" +
      "PokeAPI/sprites/master/sprites/pokemon/" +
      "other/official-artwork/" +
      id +
      ".png";
  });

  imageCache.set(id, promise);

  return promise;
}

/* ============================================================
   FORCE LANDSCAPE FOR BATTLE
   If the real viewport is narrower than it is tall when a battle
   is open, visually rotate #battlefield-page 90° with a plain CSS
   transform so the battle renders in landscape.

   This intentionally avoids the native Fullscreen / Screen-
   Orientation-Lock APIs. Those behave inconsistently across
   devices, and on some Android builds (confirmed: MIUI/Redmi
   phones, whose system-level "Game Turbo" overlay intercepts
   fullscreen requests from the browser) calling them can crash
   the page outright instead of just failing gracefully. A CSS
   transform can't trigger any of that — it's just paint, so it
   works identically (and safely) on every device, including ones
   where the Fullscreen API would have been risky or unsupported.

   Which way is "up" after a 90° turn depends on which side of the
   phone the person naturally rotates toward, and we have no safe
   way to detect that — so BOTH rotation directions are supported.
   A small flip button (only shown while rotated) lets the player
   switch sides if the first guess renders upside-down for them,
   and the choice is remembered for next time.
============================================================ */

let battleOrientationResizeHandler = null;

const BATTLE_LANDSCAPE_DIRECTION_KEY = "pf_battle_landscape_direction";

function isPortraitViewport() {
  return window.innerWidth < window.innerHeight;
}

function getBattleLandscapeDirection() {
  try {
    return localStorage.getItem(BATTLE_LANDSCAPE_DIRECTION_KEY) === "left"
      ? "left"
      : "right";
  } catch (e) {
    return "right";
  }
}

function setBattleLandscapeDirection(direction) {
  try {
    localStorage.setItem(BATTLE_LANDSCAPE_DIRECTION_KEY, direction);
  } catch (e) {
    /* Private browsing / storage disabled — the choice just won't
       persist across sessions, which is fine. */
  }
}

function applyBattleOrientation() {
  const battlefield = document.getElementById("battlefield-page");

  if (!battlefield) {
    return;
  }

  const flipBtn = document.getElementById("battle-flip-orientation");

  if (isPortraitViewport()) {
    const direction = getBattleLandscapeDirection();

    battlefield.style.width = "100dvh";
    battlefield.style.height = "100dvw";
    battlefield.style.transformOrigin = "left top";

    if (direction === "right") {
      battlefield.style.top = "0";
      battlefield.style.left = "100%";
      battlefield.style.right = "auto";
      battlefield.style.bottom = "auto";
      battlefield.style.transform = "rotate(90deg)";
    } else {
      battlefield.style.top = "100%";
      battlefield.style.left = "0";
      battlefield.style.right = "auto";
      battlefield.style.bottom = "auto";
      battlefield.style.transform = "rotate(-90deg)";
    }

    battlefield.classList.add("force-landscape-rotate");

    if (flipBtn) {
      flipBtn.classList.remove("hidden");
    }
  } else {
    battlefield.style.top = "0";
    battlefield.style.left = "0";
    battlefield.style.right = "";
    battlefield.style.bottom = "";
    battlefield.style.width = "100dvw";
    battlefield.style.height = "100dvh";
    battlefield.style.transform = "";
    battlefield.style.transformOrigin = "";

    battlefield.classList.remove("force-landscape-rotate");

    if (flipBtn) {
      flipBtn.classList.add("hidden");
    }
  }
}

function flipBattleLandscapeDirection() {
  const next = getBattleLandscapeDirection() === "right" ? "left" : "right";

  setBattleLandscapeDirection(next);

  applyBattleOrientation();
}

function enterBattleLandscape() {
  try {
    applyBattleOrientation();

    battleOrientationResizeHandler = applyBattleOrientation;

    window.addEventListener("resize", battleOrientationResizeHandler);

    const flipBtn = document.getElementById("battle-flip-orientation");

    if (flipBtn && !flipBtn.dataset.wired) {
      flipBtn.dataset.wired = "1";

      flipBtn.onclick = flipBattleLandscapeDirection;
    }
  } catch (e) {
    /* Landscape is a nice-to-have — never let it block a battle
       from starting. */
  }
}

function exitBattleLandscape() {
  try {
    if (battleOrientationResizeHandler) {
      window.removeEventListener("resize", battleOrientationResizeHandler);

      battleOrientationResizeHandler = null;
    }

    const battlefield = document.getElementById("battlefield-page");

    if (battlefield) {
      battlefield.style.top = "0";
      battlefield.style.left = "0";
      battlefield.style.right = "";
      battlefield.style.bottom = "";
      battlefield.style.width = "100dvw";
      battlefield.style.height = "100dvh";
      battlefield.style.transform = "";
      battlefield.style.transformOrigin = "";

      battlefield.classList.remove("force-landscape-rotate");
    }

    const flipBtn = document.getElementById("battle-flip-orientation");

    if (flipBtn) {
      flipBtn.classList.add("hidden");
    }
  } catch (e) {
    /* Ignore — worst case the rotated layout lingers until the
       next battle resets it. */
  }
}

/* ============================================================
   INITIALIZE GAME
============================================================ */

/* ============================================================
   INITIALIZE TEAM (6v6) BATTLE
============================================================ */

async function initTeamBattleEngine(
  homePlayerTeam,
  homeOpponentTeam,
  isTwoPlayer,
) {
  twoPlayerMode = Boolean(isTwoPlayer);

  const battlefield = document.getElementById("battlefield-page");

  if (!battlefield) {
    console.error("Battlefield missing.");

    return;
  }

  const normalizedPlayerTeam = (
    Array.isArray(homePlayerTeam) ? homePlayerTeam : [homePlayerTeam]
  )
    .map(normalizePokemon)
    .filter(Boolean);

  const normalizedEnemyTeam = (
    Array.isArray(homeOpponentTeam) ? homeOpponentTeam : [homeOpponentTeam]
  )
    .map(normalizePokemon)
    .filter(Boolean);

  if (!normalizedPlayerTeam.length || !normalizedEnemyTeam.length) {
    /* Not enough data for a team battle — fall back to 1v1. */

    return initGameEngine(normalizedPlayerTeam[0], normalizedEnemyTeam[0]);
  }

  normalizedPlayerTeam.forEach(function (p) {
    p.fainted = false;
    p.hp = GAME.maxHP;
  });

  normalizedEnemyTeam.forEach(function (p) {
    p.fainted = false;
    p.hp = GAME.maxHP;
  });

  playerTeam = normalizedPlayerTeam;
  enemyTeam = normalizedEnemyTeam;

  playerTeamIndex = 0;
  enemyTeamIndex = 0;

  playerPokemon = playerTeam[0];
  enemyPokemon = enemyTeam[0];

  /*
  Show battlefield.
  */

  battlefield.classList.remove("hidden");

  battlefield.style.display = "block";

  battlefield.style.visibility = "visible";

  battlefield.style.opacity = "1";

  battlefield.style.position = "fixed";

  battlefield.style.inset = "0";

  battlefield.style.width = "100dvw";

  battlefield.style.height = "100dvh";

  enterBattleLandscape();

  if (!createCanvas()) {
    return;
  }

  /*
  Moves are derived per active Pokémon from the type-based
  table (fast and offline-safe) rather than pre-fetched from
  PokéAPI for all 12 Pokémon up front.
  */

  playerMove = getMove(playerPokemon);

  enemyMove = getMove(enemyPokemon);

  resetBattle();

  playerImage = null;
  enemyImage = null;

  loadPokemonImage(playerPokemon).then(function (image) {
    playerImage = image;
  });

  loadPokemonImage(enemyPokemon).then(function (image) {
    enemyImage = image;
  });

  updatePokemonLabels();
  updateHealthBars();
  updateTeamPips();

  window.removeEventListener("keydown", handleKeyDown);

  window.removeEventListener("keyup", handleKeyUp);

  window.addEventListener("keydown", handleKeyDown);

  window.addEventListener("keyup", handleKeyUp);

  if (animationId) {
    cancelAnimationFrame(animationId);
  }

  gameRunning = true;
  battleEnded = false;

  lastTime = performance.now();

  draw();

  animationId = requestAnimationFrame(gameLoop);

  updateTranscript(
    "6v6 BATTLE! " +
      formatPokemonName(playerPokemon.name) +
      " VS " +
      formatPokemonName(enemyPokemon.name) +
      " • " +
      playerTeam.length +
      " vs " +
      enemyTeam.length,
  );

  console.log(
    "Team battle:",
    playerTeam.map(function (p) {
      return p.name;
    }),
    "VS",
    enemyTeam.map(function (p) {
      return p.name;
    }),
  );
}

/* ============================================================
   INITIALIZE GAME (single 1v1 — also used as the team fallback)
============================================================ */

async function initGameEngine(
  homePlayer,
  homeOpponent,
  homePlayerMove,
  homeEnemyMove,
) {
  const battlefield = document.getElementById("battlefield-page");

  if (!battlefield) {
    console.error("Battlefield missing.");

    return;
  }

  const normalizedPlayer = normalizePokemon(homePlayer);

  const normalizedEnemy = normalizePokemon(homeOpponent);

  if (normalizedPlayer) {
    playerPokemon = normalizedPlayer;
  }

  if (normalizedEnemy) {
    enemyPokemon = normalizedEnemy;
  }

  /*
  Restore saved Pokémon if necessary.
  */

  if (!normalizedPlayer || !normalizedEnemy) {
    readSavedPokemon();
  }

  playerPokemon.fainted = false;
  enemyPokemon.fainted = false;

  playerTeam = [playerPokemon];
  enemyTeam = [enemyPokemon];

  playerTeamIndex = 0;
  enemyTeamIndex = 0;

  /*
  Show battlefield.
  */

  battlefield.classList.remove("hidden");

  battlefield.style.display = "block";

  battlefield.style.visibility = "visible";

  battlefield.style.opacity = "1";

  battlefield.style.position = "fixed";

  battlefield.style.inset = "0";

  battlefield.style.width = "100dvw";

  battlefield.style.height = "100dvh";

  enterBattleLandscape();

  /*
  Canvas.
  */

  if (!createCanvas()) {
    return;
  }

  /*
  Moves.

  If real move data was fetched from PokéAPI (passed in from
  app.js), use it. Otherwise fall back to the built-in
  type-based move table so battles always work even offline.
  */

  playerMove = homePlayerMove || getMove(playerPokemon);

  enemyMove = homeEnemyMove || getMove(enemyPokemon);

  /*
  Reset.
  */

  resetBattle();

  /*
  Load images.
  */

  playerImage = null;
  enemyImage = null;

  loadPokemonImage(playerPokemon).then(function (image) {
    playerImage = image;
  });

  loadPokemonImage(enemyPokemon).then(function (image) {
    enemyImage = image;
  });

  /*
  UI.
  */

  updatePokemonLabels();
  updateHealthBars();

  /*
  Keyboard.
  */

  window.removeEventListener("keydown", handleKeyDown);

  window.removeEventListener("keyup", handleKeyUp);

  window.addEventListener("keydown", handleKeyDown);

  window.addEventListener("keyup", handleKeyUp);

  /*
  One loop only.
  */

  if (animationId) {
    cancelAnimationFrame(animationId);
  }

  gameRunning = true;
  battleEnded = false;

  lastTime = performance.now();

  draw();

  animationId = requestAnimationFrame(gameLoop);

  updateTranscript(
    formatPokemonName(playerPokemon.name) +
      " uses " +
      playerMove.name +
      " • " +
      formatPokemonName(enemyPokemon.name) +
      " is ready!",
  );

  console.log("Battle:", playerPokemon.name, "VS", enemyPokemon.name);
}

/* ============================================================
   SAVED POKÉMON
============================================================ */

function readSavedPokemon() {
  try {
    const p1 = localStorage.getItem("pokemonP1");

    const p2 = localStorage.getItem("pokemonP2");

    if (p1) {
      const parsed = JSON.parse(p1);

      const normalized = normalizePokemon(parsed);

      if (normalized) {
        playerPokemon = normalized;
      }
    }

    if (p2) {
      const parsed = JSON.parse(p2);

      const normalized = normalizePokemon(parsed);

      if (normalized) {
        enemyPokemon = normalized;
      }
    }
  } catch (error) {
    console.warn("Could not read saved Pokémon.");
  }
}

/* ============================================================
   RESET BATTLE
============================================================ */

function resetBattle() {
  resetFighter(player, GAME.playerStartX, 1);

  resetFighter(enemy, GAME.enemyStartX, -1);

  particles.length = 0;
  projectiles.length = 0;
  effects.length = 0;
  floatingTexts.length = 0;

  screenShake = 0;

  battleEnded = false;
}

/* ============================================================
   RESET FIGHTER
============================================================ */

function resetFighter(fighter, x, facing) {
  fighter.x = x;
  fighter.y = GAME.ground;

  fighter.vx = 0;
  fighter.vy = 0;

  fighter.hp = GAME.maxHP;

  fighter.facing = facing;

  fighter.jumping = false;

  fighter.attacking = false;
  fighter.blocking = false;
  fighter.dodging = false;
  fighter.invulnerable = false;

  fighter.attackTimer = 0;
  fighter.attackCooldown = 0;
  fighter.attackHit = false;

  fighter.hitTimer = 0;

  fighter.dodgeTimer = 0;

  fighter.combo = 0;
  fighter.comboTimer = 0;

  fighter.animationTime = 0;

  fighter.hitFlash = 0;

  fighter.aiThink = 100;
  fighter.aiAttackDelay = 0;
  fighter.aiBlockTimer = 0;

  fighter.swapTimer = 0;
}

/* ============================================================
   MAIN LOOP
============================================================ */

function gameLoop(time) {
  if (!gameRunning) {
    return;
  }

  let dt = (time - lastTime) / 16.6667;

  dt = clamp(dt, 0.5, 1.7);

  lastTime = time;

  update(dt);
  draw();

  animationId = requestAnimationFrame(gameLoop);
}

/* ============================================================
   UPDATE
============================================================ */

function update(dt) {
  updatePlayer(dt);

  if (twoPlayerMode) {
    updatePlayer2(dt);
  } else {
    updateEnemyAI(dt);
  }

  if (player.switchLock > 0) {
    player.switchLock -= 16.6667 * dt;
  }

  if (enemy.switchLock > 0) {
    enemy.switchLock -= 16.6667 * dt;
  }

  updatePhysics(player, enemy, dt);

  updatePhysics(enemy, player, dt);

  updateAttack(player, enemy, dt);

  updateAttack(enemy, player, dt);

  updateProjectiles(dt);

  updateParticles(dt);

  updateEffects(dt);

  updateFloatingTexts(dt);

  separateFighters();

  /*
  IMPORTANT:
  Update facing AFTER movement/separation.
  This guarantees both Pokémon look at each other.
  */

  updateFacing();

  updateScreenShake(dt);
}

/* ============================================================
   PLAYER
============================================================ */

function updatePlayer(dt) {
  player.animationTime += dt;

  if (player.hitTimer > 0) {
    return;
  }

  if (player.attacking || player.blocking || player.dodging) {
    return;
  }

  let moving = false;

  if (keys["a"]) {
    player.x -= GAME.playerSpeed * dt;

    moving = true;
  }

  if (keys["d"]) {
    player.x += GAME.playerSpeed * dt;

    moving = true;
  }

  player.vx = moving ? player.vx * 0.85 : 0;
}

/* ============================================================
   PLAYER 2 (local multiplayer — same keyboard, arrow keys)
============================================================ */

function updatePlayer2(dt) {
  enemy.animationTime += dt;

  if (enemy.hitTimer > 0) {
    return;
  }

  if (enemy.attacking || enemy.blocking || enemy.dodging) {
    return;
  }

  let moving = false;

  if (keys["arrowleft"]) {
    enemy.x -= GAME.enemySpeed * dt;

    moving = true;
  }

  if (keys["arrowright"]) {
    enemy.x += GAME.enemySpeed * dt;

    moving = true;
  }

  enemy.vx = moving ? enemy.vx * 0.85 : 0;
}

/* ============================================================
   ENEMY AI
============================================================ */

/* Difficulty tuning, set from Settings (window.AI_DIFFICULTY, one
   of "easy" | "normal" | "hard"). Scales the enemy's reaction time,
   block chance, dodge chance, and jump frequency relative to the
   normal-mode baseline used throughout updateEnemyAI(). */

const AI_DIFFICULTY_TUNING = {
  easy: { reaction: 1.6, block: 0.4, dodge: 0.5, jump: 0.6 },
  normal: { reaction: 1, block: 1, dodge: 1, jump: 1 },
  hard: { reaction: 0.55, block: 1.8, dodge: 1.7, jump: 1.3 },
};

function getAiTuning() {
  const key =
    window.AI_DIFFICULTY && AI_DIFFICULTY_TUNING[window.AI_DIFFICULTY]
      ? window.AI_DIFFICULTY
      : "normal";

  return AI_DIFFICULTY_TUNING[key];
}

function updateEnemyAI(dt) {
  enemy.animationTime += dt;

  if (enemy.hp <= 0) {
    return;
  }

  if (enemy.hitTimer > 0) {
    return;
  }

  if (enemy.attacking) {
    return;
  }

  if (enemy.dodging) {
    return;
  }

  const tuning = getAiTuning();

  const dx = player.x - enemy.x;

  const distance = Math.abs(dx);

  /*
  Enemy immediately faces player.
  */

  enemy.facing = dx >= 0 ? 1 : -1;

  /*
  Block when player attacks nearby.
  */

  if (
    player.attacking &&
    distance < 250 &&
    Math.random() < 0.025 * tuning.block
  ) {
    enemy.blocking = true;

    enemy.aiBlockTimer = 180;
  }

  if (enemy.aiBlockTimer > 0) {
    enemy.aiBlockTimer -= 16.666 * dt;

    if (enemy.aiBlockTimer <= 0) {
      enemy.blocking = false;
    }

    return;
  }

  /*
  Attack.
  */

  const attackRange = enemyMove && enemyMove.range ? enemyMove.range : 220;

  if (distance <= attackRange && enemy.attackCooldown <= 0) {
    enemy.aiAttackDelay -= 16.666 * dt;

    if (enemy.aiAttackDelay <= 0) {
      startAttack(enemy);

      enemy.aiAttackDelay = (80 + Math.random() * 90) * tuning.reaction;
    }

    return;
  }

  /*
  Approach player.
  */

  if (distance > 155) {
    const speed = GAME.enemySpeed * dt;

    enemy.x += enemy.facing * speed;

    return;
  }

  /*
  Back away if extremely close.
  */

  if (distance < 130) {
    enemy.x -= enemy.facing * 1.5 * dt;
  }

  /*
  Jump.
  */

  if (!enemy.jumping && Math.random() < 0.006 * tuning.jump) {
    jump(enemy);
  }

  /*
  Dodge incoming projectile.
  */

  if (
    projectiles.some(function (p) {
      return p.target === enemy && Math.abs(p.x - enemy.x) < 190;
    })
  ) {
    if (Math.random() < 0.25 * tuning.dodge) {
      dodge(enemy);
    }
  }
}

/* ============================================================
   PHYSICS
============================================================ */

function updatePhysics(fighter, opponent, dt) {
  /*
  Jump.
  */

  if (fighter.jumping) {
    fighter.vy += GAME.gravity * dt;

    fighter.y += fighter.vy * dt;

    if (fighter.y >= GAME.ground) {
      fighter.y = GAME.ground;

      fighter.vy = 0;

      fighter.jumping = false;

      createLandingEffect(fighter);
    }
  }

  /*
  Dodge.
  */

  if (fighter.dodging) {
    fighter.x += fighter.facing * 11 * dt;

    fighter.dodgeTimer -= 16.666 * dt;

    if (fighter.dodgeTimer <= 0) {
      fighter.dodging = false;
      fighter.invulnerable = false;
    }
  }

  /*
  Switch-in grace period (6v6 team battles).
  */

  if (fighter.swapTimer > 0) {
    fighter.swapTimer -= 16.666 * dt;

    if (fighter.swapTimer <= 0) {
      fighter.swapTimer = 0;
      fighter.invulnerable = false;
    }
  }

  /*
  Attack cooldown.
  */

  if (fighter.attackCooldown > 0) {
    fighter.attackCooldown -= 16.666 * dt;

    if (fighter.attackCooldown < 0) {
      fighter.attackCooldown = 0;
    }
  }

  /*
  Hit timer.
  */

  if (fighter.hitTimer > 0) {
    fighter.hitTimer -= 16.666 * dt;

    if (fighter.hitTimer < 0) {
      fighter.hitTimer = 0;
    }
  }

  /*
  Combo.
  */

  if (fighter.comboTimer > 0) {
    fighter.comboTimer -= 16.666 * dt;
  } else {
    fighter.combo = 0;
  }

  /*
  Hit flash.
  */

  if (fighter.hitFlash > 0) {
    fighter.hitFlash -= dt;
  }

  /*
  Arena bounds.
  */

  fighter.x = clamp(fighter.x, 90, GAME.width - 90);
}

/* ============================================================
   FACE EACH OTHER
============================================================ */

function updateFacing() {
  /*
  ============================================================
  PLAYER
  ============================================================

  If enemy is to the RIGHT:
      player faces RIGHT

  If enemy is to the LEFT:
      player faces LEFT
  */

  if (!player.dodging && player.hitTimer <= 0) {
    if (enemy.x > player.x) {
      player.facing = 1;
    } else {
      player.facing = -1;
    }
  }

  /*
  ============================================================
  ENEMY
  ============================================================

  If player is to the RIGHT:
      enemy faces RIGHT

  If player is to the LEFT:
      enemy faces LEFT
  */

  if (!enemy.dodging && enemy.hitTimer <= 0) {
    if (player.x > enemy.x) {
      enemy.facing = 1;
    } else {
      enemy.facing = -1;
    }
  }
}

/* ============================================================
   SEPARATE FIGHTERS
============================================================ */

function separateFighters() {
  const dx = enemy.x - player.x;

  const distance = Math.abs(dx);

  if (distance >= GAME.minDistance) {
    return;
  }

  const push = (GAME.minDistance - distance) / 2;

  if (dx >= 0) {
    player.x -= push;
    enemy.x += push;
  } else {
    player.x += push;
    enemy.x -= push;
  }

  player.x = clamp(player.x, 90, GAME.width - 90);

  enemy.x = clamp(enemy.x, 90, GAME.width - 90);
}

/* ============================================================
   JUMP
============================================================ */

function jump(fighter) {
  if (
    fighter.jumping ||
    fighter.attacking ||
    fighter.hitTimer > 0 ||
    fighter.dodging
  ) {
    return;
  }

  fighter.jumping = true;

  fighter.vy = GAME.jumpPower;

  createJumpEffect(fighter);
}

/* ============================================================
   DODGE
============================================================ */

function dodge(fighter) {
  if (fighter.dodging || fighter.attacking || fighter.hitTimer > 0) {
    return;
  }

  fighter.dodging = true;

  fighter.invulnerable = true;

  fighter.dodgeTimer = 220;

  fighter.x += fighter.facing * 60;

  createDashEffect(fighter);
}

/* ============================================================
   START ATTACK
============================================================ */

function startAttack(fighter) {
  if (
    fighter.attacking ||
    fighter.blocking ||
    fighter.dodging ||
    fighter.hitTimer > 0 ||
    fighter.attackCooldown > 0 ||
    fighter.hp <= 0
  ) {
    return;
  }

  fighter.attacking = true;

  fighter.attackTimer = GAME.attackDuration;

  fighter.attackCooldown = GAME.attackCooldown;

  fighter.attackHit = false;

  const move = fighter === player ? playerMove : enemyMove;

  createAttackChargeEffect(fighter, move);
}

/* ============================================================
   UPDATE ATTACK
============================================================ */

function updateAttack(attacker, target, dt) {
  if (!attacker.attacking) {
    return;
  }

  attacker.attackTimer -= 16.666 * dt;

  /*
  Hit once.
  */

  if (attacker.attackTimer <= GAME.attackHitFrame && !attacker.attackHit) {
    attacker.attackHit = true;

    performAttack(attacker, target);
  }

  /*
  Finish.
  */

  if (attacker.attackTimer <= 0) {
    attacker.attacking = false;
    attacker.attackHit = false;
  }
}

/* ============================================================
   PERFORM ATTACK
============================================================ */

function performAttack(attacker, target) {
  const move = attacker === player ? playerMove : enemyMove;

  updateTranscript(
    formatPokemonName(
      attacker === player ? playerPokemon.name : enemyPokemon.name,
    ) +
      " used " +
      move.name +
      "!",
  );

  /*
  Projectile.
  */

  if (move.projectile) {
    createProjectile(attacker, target, move);

    return;
  }

  /*
  Melee.
  */

  const distance = Math.abs(attacker.x - target.x);

  if (distance <= move.range && Math.abs(attacker.y - target.y) < 160) {
    hitTarget(attacker, target, move);
  } else {
    showText(
      attacker.x + attacker.facing * 70,
      attacker.y - 190,
      "MISS",
      "#b6c9d8",
    );
  }
}

/* ============================================================
   CREATE PROJECTILE
============================================================ */

function createProjectile(attacker, target, move) {
  if (projectiles.length >= GAME.maxProjectiles) {
    return;
  }

  const startX = attacker.x + attacker.facing * 60;

  const startY = attacker.y - 120;

  const targetX = target.x;

  const targetY = target.y - 115;

  const dx = targetX - startX;

  const dy = targetY - startY;

  const distance = Math.hypot(dx, dy) || 1;

  const speed = move.speed || 12;

  projectiles.push({
    x: startX,
    y: startY,

    vx: (dx / distance) * speed,

    vy: (dy / distance) * speed,

    attacker: attacker,
    target: target,

    move: move,

    life: 1000,

    radius: move.type === "dragon" ? 17 : 13,
  });

  addEffect({
    type: "burst",

    x: startX,
    y: startY,

    color: move.color,

    life: 150,
    maxLife: 150,

    radius: 30,
  });
}

/* ============================================================
   UPDATE PROJECTILES
============================================================ */

function updateProjectiles(dt) {
  for (let i = projectiles.length - 1; i >= 0; i--) {
    const projectile = projectiles[i];

    projectile.x += projectile.vx * dt;

    projectile.y += projectile.vy * dt;

    projectile.life -= 16.666 * dt;

    /*
    Trail.
    */

    if (particles.length < GAME.maxParticles) {
      addParticle(
        projectile.x,
        projectile.y,
        projectile.move.color,
        -projectile.vx * 0.04,
        -projectile.vy * 0.04,
        140,
        2,
      );
    }

    const target = projectile.target;

    const distance = Math.hypot(
      projectile.x - target.x,

      projectile.y - (target.y - 115),
    );

    if (distance < 50 && target.hp > 0) {
      if (target.invulnerable) {
        showText(target.x, target.y - 190, "DODGE!", "#62e7ff");

        createBurst(target.x, target.y - 115, "#62e7ff", 10);
      } else {
        hitTarget(projectile.attacker, target, projectile.move);
      }

      createImpactEffect(projectile.x, projectile.y, projectile.move);

      projectiles.splice(i, 1);

      continue;
    }

    if (
      projectile.life <= 0 ||
      projectile.x < -100 ||
      projectile.x > GAME.width + 100 ||
      projectile.y < -100 ||
      projectile.y > GAME.height + 100
    ) {
      projectiles.splice(i, 1);
    }
  }
}

/* ============================================================
   HIT TARGET
============================================================ */

function hitTarget(attacker, target, move) {
  if (target.hp <= 0 || target.invulnerable) {
    return;
  }

  let damage = move.damage || 15;

  /*
  Blocking.
  */

  if (target.blocking) {
    damage = Math.max(3, Math.round(damage * 0.25));
  }

  target.hp = clamp(target.hp - damage, 0, GAME.maxHP);

  target.hitTimer = target.blocking ? 90 : 180;

  target.hitFlash = 8;

  /*
  Knockback.
  */

  if (!target.blocking) {
    target.x += attacker.facing * 22;
  } else {
    target.x += attacker.facing * 7;
  }

  /*
  Combo.
  */

  attacker.combo += 1;

  attacker.comboTimer = 850;

  /*
  VFX.
  */

  screenShake = target.blocking ? 3 : 7;

  createImpactEffect(target.x - target.facing * 10, target.y - 115, move);

  createBurst(
    target.x,
    target.y - 115,
    target.blocking ? "#62e4ff" : move.color,
    target.blocking ? 8 : 14,
  );

  showText(target.x, target.y - 180, "-" + damage, "#ffffff");

  if (target.blocking) {
    showText(target.x, target.y - 215, "BLOCK!", "#5de4ff");
  }

  if (attacker.combo >= 2) {
    showText(
      attacker.x,
      attacker.y - 235,
      attacker.combo + " HIT COMBO",
      "#ffd43b",
    );
  }

  updateHealthBars();

  /*
  KO — send in the next team member, or end the battle if that
  was the last one standing.
  */

  if (target.hp <= 0) {
    handleFaint(target, attacker);
  }
}

/* ============================================================
   TEAM SWITCH ON FAINT (6v6)
============================================================ */

function handleFaint(target, attacker) {
  const isPlayerSide = target === player;

  const team = isPlayerSide ? playerTeam : enemyTeam;
  const currentIndex = isPlayerSide ? playerTeamIndex : enemyTeamIndex;

  if (team[currentIndex]) {
    team[currentIndex].fainted = true;
    team[currentIndex].hp = 0;
  }

  showText(
    target.x,
    target.y - 250,
    formatPokemonName(team[currentIndex] ? team[currentIndex].name : "") +
      " FAINTED!",
    "#ff6d6d",
  );

  let nextIndex = -1;

  for (let i = currentIndex + 1; i < team.length; i++) {
    if (team[i] && !team[i].fainted) {
      nextIndex = i;

      break;
    }
  }

  if (nextIndex === -1) {
    /* Whole team is down — the match is over. */

    finishBattle(attacker);

    return;
  }

  /*
  Send out the next Pokémon in the same fighter slot, fully
  healed, with a brief grace period so it isn't hit the instant
  it appears.
  */

  const startX = isPlayerSide ? GAME.playerStartX : GAME.enemyStartX;

  const facing = isPlayerSide ? 1 : -1;

  resetFighter(target, startX, facing);

  /* Honor whatever HP that team member already had (it may have
     been switched out earlier while still healthy); a Pokémon
     that's never been sent out yet starts at full health. */

  target.hp =
    typeof team[nextIndex].hp === "number" ? team[nextIndex].hp : GAME.maxHP;

  target.invulnerable = true;

  target.swapTimer = 650;

  if (isPlayerSide) {
    playerTeamIndex = nextIndex;

    playerPokemon = team[nextIndex];

    playerMove = getMove(playerPokemon);

    loadPokemonImage(playerPokemon).then(function (image) {
      playerImage = image;
    });
  } else {
    enemyTeamIndex = nextIndex;

    enemyPokemon = team[nextIndex];

    enemyMove = getMove(enemyPokemon);

    loadPokemonImage(enemyPokemon).then(function (image) {
      enemyImage = image;
    });
  }

  showText(
    target.x,
    target.y - 300,
    "GO! " + formatPokemonName(team[nextIndex].name).toUpperCase(),
    isPlayerSide ? "#8ee6b0" : "#ff9b6a",
  );

  updatePokemonLabels();
  updateHealthBars();
  updateTeamPips();
}

/* ============================================================
   VOLUNTARY SWITCH (change Pokémon mid-fight)

   Unlike handleFaint's forced swap, this can happen any time the
   active fighter isn't mid-action, and it preserves each bench
   Pokémon's own HP — recalling a Pokémon and sending it back out
   later doesn't magically heal it.
============================================================ */

function switchToIndex(isPlayerSide, newIndex) {
  if (!gameRunning || battleEnded) {
    return;
  }

  const fighter = isPlayerSide ? player : enemy;
  const team = isPlayerSide ? playerTeam : enemyTeam;
  const currentIndex = isPlayerSide ? playerTeamIndex : enemyTeamIndex;

  if (
    newIndex === currentIndex ||
    !team[newIndex] ||
    team[newIndex].fainted ||
    fighter.hp <= 0 ||
    fighter.switchLock > 0 ||
    fighter.attacking ||
    fighter.dodging ||
    fighter.hitTimer > 0
  ) {
    return;
  }

  if (team[currentIndex]) {
    team[currentIndex].hp = fighter.hp;
  }

  const startX = isPlayerSide ? GAME.playerStartX : GAME.enemyStartX;
  const facing = isPlayerSide ? 1 : -1;

  resetFighter(fighter, startX, facing);

  fighter.hp =
    typeof team[newIndex].hp === "number" ? team[newIndex].hp : GAME.maxHP;

  fighter.invulnerable = true;
  fighter.swapTimer = 500;
  fighter.switchLock = 1400;

  if (isPlayerSide) {
    playerTeamIndex = newIndex;
    playerPokemon = team[newIndex];
    playerMove = getMove(playerPokemon);

    loadPokemonImage(playerPokemon).then(function (image) {
      playerImage = image;
    });
  } else {
    enemyTeamIndex = newIndex;
    enemyPokemon = team[newIndex];
    enemyMove = getMove(enemyPokemon);

    loadPokemonImage(enemyPokemon).then(function (image) {
      enemyImage = image;
    });
  }

  showText(
    fighter.x,
    fighter.y - 300,
    "GO! " + formatPokemonName(team[newIndex].name).toUpperCase(),
    isPlayerSide ? "#8ee6b0" : "#ff9b6a",
  );

  updatePokemonLabels();
  updateHealthBars();
  updateTeamPips();
}

/*
Cycle to the next non-fainted bench Pokémon (used by the
keyboard shortcut — Tab for P1, Enter for P2).
*/

function cycleSwitch(isPlayerSide) {
  const team = isPlayerSide ? playerTeam : enemyTeam;
  const currentIndex = isPlayerSide ? playerTeamIndex : enemyTeamIndex;

  if (!team || team.length <= 1) {
    return;
  }

  for (let step = 1; step <= team.length; step++) {
    const idx = (currentIndex + step) % team.length;

    if (team[idx] && !team[idx].fainted) {
      switchToIndex(isPlayerSide, idx);
      return;
    }
  }
}

/* ============================================================
   PARTICLES
============================================================ */

function addParticle(x, y, color, vx, vy, life, size) {
  if (particles.length >= GAME.maxParticles) {
    return;
  }

  particles.push({
    x: x,
    y: y,

    vx: vx,
    vy: vy,

    life: life,
    maxLife: life,

    size: size,

    color: color,
  });
}

/* ============================================================
   BURST
============================================================ */

function createBurst(x, y, color, amount) {
  amount = Math.min(amount, GAME.maxParticles - particles.length);

  for (let i = 0; i < amount; i++) {
    const angle = Math.random() * Math.PI * 2;

    const speed = 2 + Math.random() * 5;

    addParticle(
      x,
      y,
      color,
      Math.cos(angle) * speed,
      Math.sin(angle) * speed,
      260 + Math.random() * 180,
      2 + Math.random() * 3,
    );
  }
}

/* ============================================================
   JUMP EFFECT
============================================================ */

function createJumpEffect(fighter) {
  createBurst(fighter.x, GAME.ground, "#8de8ff", 7);

  addEffect({
    type: "ring",

    x: fighter.x,
    y: GAME.ground,

    color: "#8de8ff",

    life: 220,
    maxLife: 220,

    radius: 15,
  });
}

/* ============================================================
   LAND EFFECT
============================================================ */

function createLandingEffect(fighter) {
  createBurst(fighter.x, GAME.ground, "#8de8ff", 6);

  addEffect({
    type: "ring",

    x: fighter.x,
    y: GAME.ground,

    color: "#8de8ff",

    life: 230,
    maxLife: 230,

    radius: 20,
  });
}

/* ============================================================
   DASH EFFECT
============================================================ */

function createDashEffect(fighter) {
  const color = fighter === player ? "#ffe04a" : "#ff6d9b";

  createBurst(fighter.x - fighter.facing * 35, fighter.y - 100, color, 8);

  addEffect({
    type: "dash",

    x: fighter.x,
    y: fighter.y - 110,

    color: color,

    life: 180,
    maxLife: 180,

    radius: 80,
  });
}

/* ============================================================
   ATTACK CHARGE EFFECT
============================================================ */

function createAttackChargeEffect(fighter, move) {
  addEffect({
    type: "charge",

    x: fighter.x + fighter.facing * 55,

    y: fighter.y - 120,

    color: move.color,

    life: 220,
    maxLife: 220,

    radius: 25,
  });
}

/* ============================================================
   IMPACT EFFECT
============================================================ */

function createImpactEffect(x, y, move) {
  addEffect({
    type: "impact",

    x: x,
    y: y,

    color: move.color,

    life: 220,
    maxLife: 220,

    radius: 20,
  });
}

/* ============================================================
   PARTICLE UPDATE
============================================================ */

function updateParticles(dt) {
  for (let i = particles.length - 1; i >= 0; i--) {
    const p = particles[i];

    p.x += p.vx * dt;

    p.y += p.vy * dt;

    p.vy += 0.16 * dt;

    p.life -= 16.666 * dt;

    if (p.life <= 0) {
      particles.splice(i, 1);
    }
  }
}

/* ============================================================
   EFFECTS
============================================================ */

function addEffect(effect) {
  if (effects.length >= GAME.maxEffects) {
    return;
  }

  effects.push(effect);
}

function updateEffects(dt) {
  for (let i = effects.length - 1; i >= 0; i--) {
    const effect = effects[i];

    effect.life -= 16.666 * dt;

    if (effect.life <= 0) {
      effects.splice(i, 1);
    }
  }
}

/* ============================================================
   FLOATING TEXT
============================================================ */

function showText(x, y, text, color) {
  if (floatingTexts.length >= GAME.maxFloatingTexts) {
    floatingTexts.shift();
  }

  floatingTexts.push({
    x: x,
    y: y,

    text: text,
    color: color,

    life: 750,
    maxLife: 750,
  });
}

function updateFloatingTexts(dt) {
  for (let i = floatingTexts.length - 1; i >= 0; i--) {
    const item = floatingTexts[i];

    item.y -= 0.75 * dt;

    item.life -= 16.666 * dt;

    if (item.life <= 0) {
      floatingTexts.splice(i, 1);
    }
  }
}

/* ============================================================
   SCREEN SHAKE
============================================================ */

function updateScreenShake(dt) {
  if (screenShake <= 0) {
    return;
  }

  screenShake -= 0.7 * dt;

  if (screenShake < 0) {
    screenShake = 0;
  }
}

/* ============================================================
   DRAW
============================================================ */

function draw() {
  if (!ctx || !canvas) {
    return;
  }

  ctx.clearRect(0, 0, GAME.width, GAME.height);

  ctx.save();

  if (screenShake > 0) {
    ctx.translate(
      (Math.random() - 0.5) * screenShake,

      (Math.random() - 0.5) * screenShake,
    );
  }

  drawBackground();

  drawArena();

  drawFighters();

  drawProjectiles();

  drawParticles();

  drawEffects();

  drawFloatingTexts();

  ctx.restore();
}

/* ============================================================
   BACKGROUND
============================================================ */

function drawBackground() {
  const t = performance.now() * 0.001;

  /*
  Sky gradient.
  */

  const gradient = ctx.createLinearGradient(0, 0, 0, GAME.height);

  gradient.addColorStop(0, "#050d1c");

  gradient.addColorStop(0.42, "#0d2540");

  gradient.addColorStop(0.72, "#164060");

  gradient.addColorStop(1, "#06131f");

  ctx.fillStyle = gradient;

  ctx.fillRect(0, 0, GAME.width, GAME.height);

  /*
  Aurora-style glow bands.
  */

  ctx.save();

  ctx.globalAlpha = 0.16;

  const auroraA = ctx.createRadialGradient(
    GAME.width * 0.22,
    90,
    20,
    GAME.width * 0.22,
    90,
    340,
  );

  auroraA.addColorStop(0, "#7d45ff");
  auroraA.addColorStop(1, "rgba(125,69,255,0)");

  ctx.fillStyle = auroraA;
  ctx.fillRect(0, 0, GAME.width, GAME.height * 0.6);

  const auroraB = ctx.createRadialGradient(
    GAME.width * 0.8,
    60,
    20,
    GAME.width * 0.8,
    60,
    380,
  );

  auroraB.addColorStop(0, "#21b5ff");
  auroraB.addColorStop(1, "rgba(33,181,255,0)");

  ctx.fillStyle = auroraB;
  ctx.fillRect(0, 0, GAME.width, GAME.height * 0.6);

  ctx.restore();

  /*
  Twinkling stars.
  */

  for (let i = 0; i < 40; i++) {
    const x = 20 + ((i * 173) % (GAME.width - 40));

    const y = 20 + ((i * 71) % 230);

    const twinkle = 0.35 + 0.35 * Math.sin(t * 1.6 + i * 12.9);

    ctx.fillStyle = "rgba(180,225,255," + clamp(twinkle, 0.1, 0.85) + ")";

    ctx.fillRect(x, y, i % 5 === 0 ? 2.4 : 1.6, i % 5 === 0 ? 2.4 : 1.6);
  }

  /*
  Distant mountain / skyline silhouette.
  */

  ctx.save();

  ctx.fillStyle = "#0a1f34";

  ctx.beginPath();

  ctx.moveTo(0, GAME.ground - 78);

  const peaks = 9;

  for (let i = 0; i <= peaks; i++) {
    const x = (GAME.width / peaks) * i;

    const peakHeight = 40 + ((i * 53) % 70);

    ctx.lineTo(x, GAME.ground - 78 - peakHeight);
  }

  ctx.lineTo(GAME.width, GAME.ground - 78);

  ctx.closePath();

  ctx.fill();

  ctx.restore();

  /*
  Floodlight beams sweeping from the top corners.
  */

  ctx.save();

  ctx.globalAlpha = 0.1;

  drawFloodlight(70, -20, Math.sin(t * 0.35) * 0.12 + 0.55);

  drawFloodlight(GAME.width - 70, -20, Math.sin(t * 0.35 + 2) * 0.12 - 0.55);

  ctx.restore();
}

/* ============================================================
   FLOODLIGHT BEAM
============================================================ */

function drawFloodlight(x, y, angle) {
  const length = 620;

  const spread = 0.32;

  ctx.save();

  ctx.translate(x, y);

  ctx.rotate(Math.PI / 2 + angle);

  const beam = ctx.createLinearGradient(0, 0, length, 0);

  beam.addColorStop(0, "rgba(150,220,255,.9)");

  beam.addColorStop(1, "rgba(150,220,255,0)");

  ctx.fillStyle = beam;

  ctx.beginPath();

  ctx.moveTo(0, 0);

  ctx.lineTo(length, -Math.tan(spread) * length);

  ctx.lineTo(length, Math.tan(spread) * length);

  ctx.closePath();

  ctx.fill();

  ctx.restore();
}

/* ============================================================
   ARENA
============================================================ */

function drawArena() {
  const t = performance.now() * 0.001;

  /*
  Back wall / stand riser.
  */

  ctx.fillStyle = "#0b2638";

  ctx.fillRect(0, GAME.ground - 80, GAME.width, 80);

  /*
  Crowd stands: rows of small glowing dots receding upward.
  */

  ctx.save();

  const rows = 4;

  for (let r = 0; r < rows; r++) {
    const rowY = GAME.ground - 74 + r * 15;

    const count = 46 - r * 4;

    const spacing = GAME.width / count;

    ctx.globalAlpha = 0.5 - r * 0.09;

    for (let i = 0; i < count; i++) {
      const flicker = 0.5 + 0.5 * Math.sin(t * 3 + i * 7.3 + r * 4);

      const hue = (i + r) % 5 === 0 ? "#ffcf6b" : "#6fb8ff";

      ctx.fillStyle = hue;

      ctx.globalAlpha *= 1;

      ctx.fillRect(
        i * spacing + (r % 2 === 0 ? 0 : spacing / 2),
        rowY,
        3,
        3 + flicker * 1.5,
      );
    }
  }

  ctx.restore();

  /*
  Floor gradient.
  */

  const floor = ctx.createLinearGradient(0, GAME.ground, 0, GAME.height);

  floor.addColorStop(0, "#1a5570");

  floor.addColorStop(0.4, "#123f56");

  floor.addColorStop(1, "#05111c");

  ctx.fillStyle = floor;

  ctx.fillRect(0, GAME.ground, GAME.width, GAME.height - GAME.ground);

  /*
  Perspective floor tiles converging toward the horizon line.
  */

  ctx.save();

  ctx.strokeStyle = "rgba(103,225,255,.14)";

  ctx.lineWidth = 1;

  const vanishX = GAME.width / 2;

  for (let i = -10; i <= 10; i++) {
    ctx.beginPath();

    ctx.moveTo(vanishX + i * 60, GAME.ground);

    ctx.lineTo(vanishX + i * 340, GAME.height);

    ctx.stroke();
  }

  for (let i = 1; i <= 6; i++) {
    const y = GAME.ground + (GAME.height - GAME.ground) * (i / 6.5) * (i / 6.5);

    ctx.beginPath();

    ctx.moveTo(0, y);

    ctx.lineTo(GAME.width, y);

    ctx.stroke();
  }

  ctx.restore();

  /*
  Glowing horizon line.
  */

  ctx.fillStyle = "#64e2ff";

  ctx.fillRect(0, GAME.ground, GAME.width, 4);

  ctx.save();

  ctx.globalAlpha = 0.5;

  ctx.fillStyle = "#64e2ff";

  ctx.fillRect(0, GAME.ground - 3, GAME.width, 3);

  ctx.restore();

  /*
  Center battle circle with slowly rotating energy rings.
  */

  const cx = GAME.width / 2;

  const cy = GAME.ground + 30;

  ctx.save();

  ctx.strokeStyle = "rgba(103,225,255,.5)";

  ctx.lineWidth = 3;

  ctx.beginPath();

  ctx.ellipse(cx, cy, 490, 90, 0, 0, Math.PI * 2);

  ctx.stroke();

  ctx.save();

  ctx.translate(cx, cy);

  ctx.rotate(t * 0.15);

  ctx.strokeStyle = "rgba(125,200,255,.55)";

  ctx.lineWidth = 2;

  ctx.setLineDash([14, 10]);

  ctx.beginPath();

  ctx.ellipse(0, 0, 80, 20, 0, 0, Math.PI * 2);

  ctx.stroke();

  ctx.restore();

  ctx.setLineDash([]);

  ctx.strokeStyle = "rgba(100,225,255,.35)";

  ctx.lineWidth = 2;

  ctx.beginPath();

  ctx.ellipse(cx, cy, 250, 48, 0, 0, Math.PI * 2);

  ctx.stroke();

  ctx.restore();

  /*
  Center divider.
  */

  ctx.fillStyle = "rgba(100,225,255,.18)";

  ctx.fillRect(cx - 2, GAME.ground - 30, 4, 80);

  /*
  Vignette.
  */

  ctx.save();

  const vignette = ctx.createRadialGradient(
    cx,
    GAME.ground - 40,
    GAME.height * 0.25,
    cx,
    GAME.ground - 40,
    GAME.height * 0.95,
  );

  vignette.addColorStop(0, "rgba(0,0,0,0)");

  vignette.addColorStop(1, "rgba(0,4,10,.55)");

  ctx.fillStyle = vignette;

  ctx.fillRect(0, 0, GAME.width, GAME.height);

  ctx.restore();
}

/* ============================================================
   DRAW FIGHTERS
============================================================ */

function drawFighters() {
  drawFighter(player, playerPokemon, playerImage);

  drawFighter(enemy, enemyPokemon, enemyImage);
}

/* ============================================================
   DRAW FIGHTER
============================================================ */

function drawFighter(fighter, pokemon, image) {
  const sizeScale = getSizeScale(pokemon);

  /*
  Shadow. Scaled with the Pokémon so bigger fighters cast a
  bigger shadow and tiny ones cast a small one.
  */

  ctx.save();

  ctx.fillStyle = "rgba(0,0,0,.35)";

  ctx.beginPath();

  ctx.ellipse(
    fighter.x,
    GAME.ground + 7,

    (fighter.jumping ? 40 : 65) * sizeScale,

    (fighter.jumping ? 8 : 16) * sizeScale,

    0,
    0,
    Math.PI * 2,
  );

  ctx.fill();

  ctx.restore();

  /*
  Fighter transform.
  */

  ctx.save();

  ctx.translate(fighter.x, fighter.y);

  /*
  Idle animation.
  */

  const idleBounce =
    !fighter.jumping &&
    !fighter.attacking &&
    !fighter.hitTimer &&
    !fighter.dodging
      ? Math.sin(fighter.animationTime * 0.08) * 6
      : 0;

  /* Gentle side-to-side sway so idle Pokémon never look frozen,
     even between bounces. */
  const idleSway =
    !fighter.jumping &&
    !fighter.attacking &&
    !fighter.hitTimer &&
    !fighter.dodging
      ? Math.sin(fighter.animationTime * 0.035) * 3
      : 0;

  const jumpBounce = fighter.jumping
    ? Math.sin(fighter.animationTime * 0.2) * 2
    : 0;

  ctx.translate(idleSway, idleBounce + jumpBounce);

  /*
  Dodge.
  */

  if (fighter.dodging) {
    ctx.globalAlpha = 0.5;
  }

  /*
  Hit animation.
  */

  if (fighter.hitTimer > 0) {
    ctx.translate(Math.sin(fighter.hitTimer * 0.35) * 7, 0);
  }

  /*
  Pokémon image.
  */

  if (image && image.complete && image.naturalWidth > 0) {
    drawPokemonImage(fighter, image, pokemon);
  } else {
    drawFallbackPokemon(fighter);
  }

  /*
  Shield.
  */

  if (fighter.blocking) {
    drawShield(fighter);
  }

  /*
  Melee attack.
  */

  if (fighter.attacking) {
    const move = fighter === player ? playerMove : enemyMove;

    if (!move.projectile) {
      drawMeleeAttack(fighter, move);
    }
  }

  /*
  Hit flash.
  */

  if (fighter.hitFlash > 0) {
    ctx.fillStyle = "rgba(255,255,255,.24)";

    ctx.beginPath();

    ctx.arc(0, -115, 75, 0, Math.PI * 2);

    ctx.fill();
  }

  ctx.restore();

  drawName(fighter, pokemon, sizeScale);
}

/* ============================================================
   DRAW POKÉMON IMAGE
============================================================ */

/*
IMPORTANT ORIENTATION FIX

Most official Pokémon artwork is drawn facing toward the
LEFT side of the image, but not all of it — some Pokémon
(see ARTWORK_FACES_RIGHT above) are drawn in action poses
that face RIGHT instead.

getArtworkNaturalFacing() looks up which way this
particular Pokémon's artwork naturally faces, and we only
mirror it when that natural facing doesn't already match
the direction the fighter needs to face.

This makes:

PLAYER  --->    <---  ENEMY
============================================================
*/

function drawPokemonImage(fighter, image, pokemon) {
  /* Real-world size relative to the opponent, instead of every
     Pokémon rendering at the same fixed size. */
  const size = 245 * getSizeScale(pokemon);

  ctx.save();

  /*
  Breathing animation — a slow, subtle squash/stretch so even a
  fully idle Pokémon still reads as "alive" up close, layered on
  top of the whole-body idle bob/sway applied in drawFighter().
  */

  if (
    !fighter.jumping &&
    !fighter.attacking &&
    !fighter.hitTimer &&
    !fighter.dodging
  ) {
    const breathe = 1 + Math.sin(fighter.animationTime * 0.06) * 0.02;

    ctx.scale(1, breathe);
  }

  /*
  ============================================================
  FACE EACH OTHER
  ============================================================

  naturalFacing = which way the artwork already faces
  fighter.facing = which way the fighter needs to face

  Mirror only when they disagree.
  */

  const naturalFacing = getArtworkNaturalFacing(pokemon);

  ctx.scale(naturalFacing * fighter.facing, 1);

  /*
  Jump animation.
  */

  if (fighter.jumping) {
    ctx.rotate(fighter.facing * -0.045);

    ctx.scale(0.97, 1.03);
  }

  /*
  Dodge animation.
  */

  if (fighter.dodging) {
    ctx.scale(1.12, 0.88);
  }

  /*
  Attack animation.

  Move forward in the direction
  the Pokémon is facing.
  */

  if (fighter.attacking) {
    const progress = 1 - fighter.attackTimer / GAME.attackDuration;

    const attackProgress = clamp(progress, 0, 1);

    const attackMove = Math.sin(attackProgress * Math.PI) * 18;

    ctx.translate(attackMove, 0);

    ctx.rotate(Math.sin(attackProgress * Math.PI) * 0.035);
  }

  /*
  Attack / hit glow.
  */

  if (fighter.attacking || fighter.hitTimer > 0) {
    ctx.shadowColor = fighter === player ? "#ffe14a" : "#ff6688";

    ctx.shadowBlur = 12;
  }

  /*
  Draw artwork.
  */

  ctx.drawImage(image, -size / 2, -size + 15, size, size);

  ctx.shadowBlur = 0;

  ctx.restore();
}

/* ============================================================
   FALLBACK POKÉMON
============================================================ */

function drawFallbackPokemon(fighter) {
  const color = fighter === player ? "#ffd43b" : "#ef476f";

  ctx.save();

  /*
  Also make fallback face the
  same direction as the real
  Pokémon.
  */

  ctx.scale(fighter.facing, 1);

  ctx.fillStyle = color;

  ctx.beginPath();

  ctx.ellipse(0, -90, 58, 72, 0, 0, Math.PI * 2);

  ctx.fill();

  ctx.beginPath();

  ctx.arc(0, -165, 50, 0, Math.PI * 2);

  ctx.fill();

  ctx.fillStyle = "#111827";

  ctx.beginPath();

  ctx.arc(-17, -170, 7, 0, Math.PI * 2);

  ctx.arc(17, -170, 7, 0, Math.PI * 2);

  ctx.fill();

  ctx.restore();
}

/* ============================================================
   NAME
============================================================ */

function drawName(fighter, pokemon, sizeScale) {
  ctx.save();

  ctx.textAlign = "center";

  ctx.font = "bold 19px Arial";

  ctx.fillStyle = "#ffffff";

  ctx.strokeStyle = "#06111d";

  ctx.lineWidth = 5;

  /* Nametag floats above the sprite's actual (scaled) height so it
     doesn't overlap a giant Pokémon or hover too far above a tiny one. */
  const scale = typeof sizeScale === "number" ? sizeScale : 1;

  const nameY = fighter.y - 245 * scale - 20;

  ctx.strokeText(formatPokemonName(pokemon.name), fighter.x, nameY);

  ctx.fillText(formatPokemonName(pokemon.name), fighter.x, nameY);

  ctx.restore();
}

/* ============================================================
   SHIELD
============================================================ */

function drawShield(fighter) {
  ctx.save();

  ctx.strokeStyle = "#5de4ff";

  ctx.lineWidth = 6;

  ctx.globalAlpha = 0.75;

  ctx.beginPath();

  if (fighter.facing === 1) {
    ctx.arc(50, -110, 78, -Math.PI / 2, Math.PI / 2);
  } else {
    ctx.arc(-50, -110, 78, Math.PI / 2, Math.PI * 1.5);
  }

  ctx.stroke();

  ctx.restore();
}

/* ============================================================
   MELEE ATTACK
============================================================ */

function drawMeleeAttack(fighter, move) {
  const progress = 1 - fighter.attackTimer / GAME.attackDuration;

  if (progress < 0.2) {
    return;
  }

  const alpha = clamp(Math.sin(progress * Math.PI), 0, 1);

  ctx.save();

  ctx.globalAlpha = alpha;

  ctx.strokeStyle = move.color;

  ctx.lineWidth = 10;

  ctx.beginPath();

  if (fighter.facing === 1) {
    ctx.arc(70, -110, 85, -1.15, 1.15);
  } else {
    ctx.arc(-70, -110, 85, Math.PI - 1.15, Math.PI + 1.15);
  }

  ctx.stroke();

  ctx.restore();
}

/* ============================================================
   DRAW PROJECTILES
============================================================ */

function drawProjectiles() {
  for (let i = 0; i < projectiles.length; i++) {
    const p = projectiles[i];

    ctx.save();

    ctx.shadowColor = p.move.color;

    ctx.shadowBlur = 12;

    if (p.move.type === "electric") {
      drawLightningOrb(p.x, p.y, p.radius);
    } else if (p.move.type === "water") {
      drawWaterOrb(p.x, p.y, p.radius);
    } else if (p.move.type === "fire") {
      drawFireball(p.x, p.y, p.radius);
    } else if (p.move.type === "ghost") {
      drawGhostBall(p.x, p.y, p.radius);
    } else {
      drawGenericOrb(p.x, p.y, p.radius, p.move.color);
    }

    ctx.restore();
  }
}

/* ============================================================
   ELECTRIC PROJECTILE
============================================================ */

function drawLightningOrb(x, y, radius) {
  ctx.fillStyle = "#ffe14a";

  ctx.beginPath();

  ctx.arc(x, y, radius, 0, Math.PI * 2);

  ctx.fill();

  ctx.strokeStyle = "#fff9a6";

  ctx.lineWidth = 3;

  ctx.beginPath();

  ctx.moveTo(x - radius, y);

  ctx.lineTo(x - 3, y - radius);

  ctx.lineTo(x + 2, y + 3);

  ctx.lineTo(x + radius, y - 4);

  ctx.stroke();
}

/* ============================================================
   WATER PROJECTILE
============================================================ */

function drawWaterOrb(x, y, radius) {
  ctx.fillStyle = "#42b9ff";

  ctx.beginPath();

  ctx.arc(x, y, radius, 0, Math.PI * 2);

  ctx.fill();

  ctx.globalAlpha = 0.45;

  ctx.fillStyle = "#d5f6ff";

  ctx.beginPath();

  ctx.arc(x - 4, y - 4, radius * 0.45, 0, Math.PI * 2);

  ctx.fill();
}

/* ============================================================
   FIRE PROJECTILE
============================================================ */

function drawFireball(x, y, radius) {
  ctx.fillStyle = "#ff6a22";

  ctx.beginPath();

  ctx.arc(x, y, radius, 0, Math.PI * 2);

  ctx.fill();

  ctx.fillStyle = "#fff2a3";

  ctx.beginPath();

  ctx.arc(x - 3, y - 3, radius * 0.45, 0, Math.PI * 2);

  ctx.fill();
}

/* ============================================================
   GHOST PROJECTILE
============================================================ */

function drawGhostBall(x, y, radius) {
  ctx.fillStyle = "#a75bea";

  ctx.beginPath();

  ctx.arc(x, y, radius, 0, Math.PI * 2);

  ctx.fill();

  ctx.globalAlpha = 0.55;

  ctx.strokeStyle = "#e1b5ff";

  ctx.lineWidth = 3;

  ctx.stroke();
}

/* ============================================================
   GENERIC PROJECTILE
============================================================ */

function drawGenericOrb(x, y, radius, color) {
  ctx.fillStyle = color;

  ctx.beginPath();

  ctx.arc(x, y, radius, 0, Math.PI * 2);

  ctx.fill();

  ctx.globalAlpha = 0.35;

  ctx.fillStyle = "#ffffff";

  ctx.beginPath();

  ctx.arc(x - 4, y - 4, radius * 0.4, 0, Math.PI * 2);

  ctx.fill();
}

/* ============================================================
   PARTICLE DRAW
============================================================ */

function drawParticles() {
  if (!particles.length) {
    return;
  }

  for (let i = 0; i < particles.length; i++) {
    const p = particles[i];

    ctx.globalAlpha = clamp(p.life / p.maxLife, 0, 1);

    ctx.fillStyle = p.color;

    ctx.fillRect(p.x, p.y, p.size, p.size);
  }

  ctx.globalAlpha = 1;
}

/* ============================================================
   EFFECT DRAW
============================================================ */

function drawEffects() {
  for (let i = 0; i < effects.length; i++) {
    const effect = effects[i];

    const progress = 1 - effect.life / effect.maxLife;

    const alpha = 1 - progress;

    ctx.save();

    ctx.globalAlpha = alpha;

    ctx.strokeStyle = effect.color;

    ctx.fillStyle = effect.color;

    if (effect.type === "ring") {
      const radius = effect.radius + progress * 70;

      ctx.lineWidth = 4;

      ctx.beginPath();

      ctx.arc(effect.x, effect.y, radius, 0, Math.PI * 2);

      ctx.stroke();
    } else if (effect.type === "burst") {
      const radius = effect.radius * (1 + progress);

      ctx.lineWidth = 3;

      ctx.beginPath();

      ctx.arc(effect.x, effect.y, radius, 0, Math.PI * 2);

      ctx.stroke();
    } else if (effect.type === "impact") {
      const radius = effect.radius + progress * 55;

      ctx.lineWidth = 8 * (1 - progress);

      ctx.beginPath();

      ctx.arc(effect.x, effect.y, radius, 0, Math.PI * 2);

      ctx.stroke();

      for (let r = 0; r < 6; r++) {
        const angle = (r * Math.PI) / 3;

        const x1 = effect.x + Math.cos(angle) * radius;

        const y1 = effect.y + Math.sin(angle) * radius;

        const x2 = effect.x + Math.cos(angle) * (radius + 25);

        const y2 = effect.y + Math.sin(angle) * (radius + 25);

        ctx.beginPath();

        ctx.moveTo(x1, y1);

        ctx.lineTo(x2, y2);

        ctx.stroke();
      }
    } else if (effect.type === "charge") {
      const radius = effect.radius + Math.sin(progress * Math.PI) * 20;

      ctx.lineWidth = 4;

      ctx.beginPath();

      ctx.arc(effect.x, effect.y, radius, 0, Math.PI * 2);

      ctx.stroke();
    } else if (effect.type === "dash") {
      ctx.lineWidth = 5;

      ctx.beginPath();

      ctx.arc(
        effect.x,
        effect.y,
        effect.radius * (1 - progress),
        0,
        Math.PI * 2,
      );

      ctx.stroke();
    }

    ctx.restore();
  }
}

/* ============================================================
   FLOATING TEXT DRAW
============================================================ */

function drawFloatingTexts() {
  for (let i = 0; i < floatingTexts.length; i++) {
    const item = floatingTexts[i];

    ctx.save();

    ctx.globalAlpha = clamp(item.life / item.maxLife, 0, 1);

    ctx.textAlign = "center";

    ctx.font = "900 23px Arial";

    ctx.fillStyle = item.color;

    ctx.strokeStyle = "#06111d";

    ctx.lineWidth = 5;

    ctx.strokeText(item.text, item.x, item.y);

    ctx.fillText(item.text, item.x, item.y);

    ctx.restore();
  }
}

/* ============================================================
   KEY DOWN
============================================================ */

function handleKeyDown(e) {
  const key = e.key.toLowerCase();

  keys[key] = true;

  if (
    [
      "w",
      "a",
      "s",
      "d",
      "q",
      "shift",
      "tab",
      "enter",
      "arrowup",
      "arrowdown",
      "arrowleft",
      "arrowright",
      "/",
    ].includes(key)
  ) {
    e.preventDefault();
  }

  /*
  Block is handled per-side below via e.code, since P1 uses the
  left Shift key and P2 (local multiplayer) uses the right one.
  */

  if (key === "shift" && e.code !== "ShiftRight") {
    player.blocking = true;
  }

  if (twoPlayerMode && e.code === "ShiftRight") {
    enemy.blocking = true;
  }

  if (e.repeat) {
    return;
  }

  if (key === "w") {
    jump(player);
  }

  if (key === "s") {
    startAttack(player);
  }

  if (key === "q") {
    dodge(player);
  }

  /* Switch active Pokémon mid-fight. Tab always switches P1's
     team; Enter switches P2's team when local 2-player is on. */

  if (key === "tab") {
    cycleSwitch(true);
  }

  if (key === "enter" && twoPlayerMode) {
    cycleSwitch(false);
  }

  /* Local 2-player controls (arrow keys / slash), only live
     when a second human has taken over the enemy side. */

  if (twoPlayerMode) {
    if (key === "arrowup") {
      jump(enemy);
    }

    if (key === "arrowdown") {
      startAttack(enemy);
    }

    if (key === "/") {
      dodge(enemy);
    }
  }
}

/* ============================================================
   KEY UP
============================================================ */

function handleKeyUp(e) {
  const key = e.key.toLowerCase();

  keys[key] = false;

  if (key === "shift" && e.code !== "ShiftRight") {
    player.blocking = false;
  }

  if (twoPlayerMode && e.code === "ShiftRight") {
    enemy.blocking = false;
  }
}

/* ============================================================
   HEALTH BARS
============================================================ */

function updateHealthBars() {
  const p1 = document.getElementById("p1-hp");

  const p2 = document.getElementById("p2-hp");

  if (p1) {
    p1.style.width = clamp(player.hp, 0, 100) + "%";
  }

  if (p2) {
    p2.style.width = clamp(enemy.hp, 0, 100) + "%";
  }
}

/* ============================================================
   TEAM PIPS (6v6 roster status)
============================================================ */

function updateTeamPips() {
  renderTeamPips("p1-team-pips", playerTeam, playerTeamIndex);
  renderTeamPips("p2-team-pips", enemyTeam, enemyTeamIndex);
}

function renderTeamPips(elementId, team, currentIndex) {
  const el = document.getElementById(elementId);

  if (!el) {
    return;
  }

  if (!team || team.length <= 1) {
    el.innerHTML = "";

    return;
  }

  const isPlayerSide = elementId === "p1-team-pips";

  /* Enemy pips only become switchable when a human (not the AI)
     is controlling that side. */
  const clickable = isPlayerSide || twoPlayerMode;

  let html = "";

  for (let i = 0; i < team.length; i++) {
    const fainted = team[i] && team[i].fainted;

    const isCurrent = i === currentIndex && !fainted;

    let cls = "pip";

    if (fainted) {
      cls += " pip-fainted";
    } else if (isCurrent) {
      cls += " pip-current";
    } else {
      cls += " pip-alive";

      if (clickable) {
        cls += " pip-clickable";
      }
    }

    html += '<span class="' + cls + '" data-index="' + i + '"></span>';
  }

  el.innerHTML = html;

  if (clickable) {
    el.querySelectorAll(".pip-clickable").forEach(function (pip) {
      pip.onclick = function () {
        switchToIndex(isPlayerSide, Number(pip.dataset.index));
      };
    });
  }
}

/* ============================================================
   POKÉMON LABELS
============================================================ */

function updatePokemonLabels() {
  const p1 = document.getElementById("p1-label");

  const p2 = document.getElementById("p2-label");

  if (p1) {
    p1.textContent = formatPokemonName(playerPokemon.name);
  }

  if (p2) {
    p2.textContent = formatPokemonName(enemyPokemon.name);
  }

  /*
  Home-compatible labels.
  */

  const playerName = document.getElementById("player-name");

  const enemyName = document.getElementById("enemy-name");

  if (playerName) {
    playerName.textContent = formatPokemonName(playerPokemon.name);
  }

  updateTeamPips();

  if (enemyName) {
    enemyName.textContent = formatPokemonName(enemyPokemon.name);
  }

  /*
  Type labels.
  */

  const playerType = document.getElementById("player-type");

  const enemyType = document.getElementById("enemy-type");

  if (playerType) {
    playerType.textContent = getPokemonType(playerPokemon).toUpperCase();
  }

  if (enemyType) {
    enemyType.textContent = getPokemonType(enemyPokemon).toUpperCase();
  }

  /*
  Controls.
  */

  const p1Text =
    formatPokemonName(playerPokemon.name) +
    ": W Jump • A/D Move • S " +
    playerMove.name +
    " • Q Dodge • Shift Block • Tab Switch";

  const p2Text = twoPlayerMode
    ? formatPokemonName(enemyPokemon.name) +
      ": ↑ Jump • ←/→ Move • ↓ " +
      enemyMove.name +
      " • / Dodge • RShift Block • Enter Switch"
    : formatPokemonName(enemyPokemon.name) + ": AI";

  updateTranscript(p1Text + " | " + p2Text);
}

/* ============================================================
   TRANSCRIPT
============================================================ */

function updateTranscript(text) {
  const element = document.getElementById("controls-transcript");

  if (element) {
    element.textContent = text;
  }
}

/* ============================================================
   FINISH BATTLE
============================================================ */

function finishBattle(winner) {
  if (battleEnded) {
    return;
  }

  battleEnded = true;

  gameRunning = false;

  if (animationId) {
    cancelAnimationFrame(animationId);

    animationId = null;
  }

  const playerWon = winner === player;

  const isTeamBattle = playerTeam.length > 1 || enemyTeam.length > 1;

  const bannerText = isTeamBattle
    ? playerWon
      ? "YOU WIN THE BATTLE!"
      : formatPokemonName(enemyPokemon.name).toUpperCase() + "'S TEAM WINS!"
    : formatPokemonName(
        winner === player ? playerPokemon.name : enemyPokemon.name,
      ) + " WINS!";

  createBurst(GAME.width / 2, 210, "#ffd43b", 20);

  showText(GAME.width / 2, 170, bannerText, "#ffd43b");

  updateTranscript("🏆 " + bannerText);

  draw();

  setTimeout(function () {
    exitBattleLandscape();

    const battlefield = document.getElementById("battlefield-page");

    const home = document.getElementById("home-page");

    if (battlefield) {
      battlefield.classList.add("hidden");
    }

    if (home) {
      home.classList.remove("hidden");
    }

    /*
    Let app.js know how the battle ended (used to capture the
    opponent's Pokémon on a win). Defined outside game.js so
    game.js has no direct dependency on the capture feature.
    */

    if (typeof window.onBattleFinished === "function") {
      window.onBattleFinished(
        playerWon,
        enemyPokemon,
        playerPokemon,
        enemyTeam,
        playerTeam,
      );
    }
  }, 1800);
}

/* ============================================================
   STOP GAME
============================================================ */

function stopGame() {
  gameRunning = false;

  if (animationId) {
    cancelAnimationFrame(animationId);

    animationId = null;
  }

  window.removeEventListener("keydown", handleKeyDown);

  window.removeEventListener("keyup", handleKeyUp);
}

/* ============================================================
   PUBLIC API
============================================================ */

window.PokemonBattle = {
  start: function (homePlayer, homeOpponent, homePlayerMove, homeEnemyMove) {
    initGameEngine(homePlayer, homeOpponent, homePlayerMove, homeEnemyMove);
  },

  startTeam: function (homePlayerTeam, homeOpponentTeam, isTwoPlayer) {
    initTeamBattleEngine(homePlayerTeam, homeOpponentTeam, isTwoPlayer);
  },

  restart: function () {
    /* Full rematch — everyone's back in, nobody's fainted. */

    playerTeam.forEach(function (p) {
      p.fainted = false;
      p.hp = GAME.maxHP;
    });

    enemyTeam.forEach(function (p) {
      p.fainted = false;
      p.hp = GAME.maxHP;
    });

    player.switchLock = 0;
    enemy.switchLock = 0;

    playerTeamIndex = 0;
    enemyTeamIndex = 0;

    playerPokemon = playerTeam[0] || playerPokemon;
    enemyPokemon = enemyTeam[0] || enemyPokemon;

    resetBattle();

    updatePokemonLabels();
    updateTeamPips();

    /*
    Keep whatever moves are already active (which may be
    real API-fetched moves) instead of recomputing the
    type-based fallback on every rematch.
    */

    playerMove = getMove(playerPokemon);

    enemyMove = getMove(enemyPokemon);

    gameRunning = true;

    battleEnded = false;

    lastTime = performance.now();

    if (animationId) {
      cancelAnimationFrame(animationId);
    }

    animationId = requestAnimationFrame(gameLoop);
  },

  stop: function () {
    stopGame();
  },

  getPokemon: function () {
    return {
      player: playerPokemon,

      enemy: enemyPokemon,
    };
  },

  attack: function () {
    startAttack(player);
  },

  jump: function () {
    jump(player);
  },

  dodge: function () {
    dodge(player);
  },

  block: function (value) {
    player.blocking = Boolean(value);
  },
};

/* ============================================================
   GLOBAL SELECTION API
============================================================ */

window.setBattlePokemon = function (p1, p2) {
  const first = normalizePokemon(p1);

  const second = normalizePokemon(p2);

  if (first) {
    playerPokemon = first;
  }

  if (second) {
    enemyPokemon = second;
  }

  playerMove = getMove(playerPokemon);

  enemyMove = getMove(enemyPokemon);

  updatePokemonLabels();

  try {
    localStorage.setItem("pokemonP1", JSON.stringify(playerPokemon));

    localStorage.setItem("pokemonP2", JSON.stringify(enemyPokemon));
  } catch (error) {
    console.warn("Could not save battle Pokémon.");
  }
};

/* ============================================================
   EXPOSE TYPE MOVE VISUALS
============================================================

app.js fetches each fighter's real moves from PokéAPI and
needs sane projectile/color/range/speed defaults per type
to render them. Expose the existing table read-only.
============================================================ */

window.TYPE_MOVES = TYPE_MOVES;

/* ============================================================
   STARTUP
============================================================ */

console.log("Pokémon Fighter universal game.js loaded.");
