/* Pokémon Fighter — Service Worker
   Enables the "Install app" / offline-download feature on desktop.

   Strategy:
   - App shell (HTML/CSS/JS/icons): network-first — always try to
     fetch the latest version first, and only fall back to whatever
     was last cached if there's no connection. This is what makes a
     deploy (e.g. a new Google OAuth Client ID, a bug fix) show up
     immediately for anyone online, instead of everyone being stuck
     on a stale cached build until they happen to clear site data.
     (Cache-first was used previously, but a stale cached app.js is
     exactly what caused the earlier sign-in "origin_mismatch" bug —
     the browser kept serving an old build with an old client ID.)
   - Pokémon data & sprite images (PokeAPI + raw.githubusercontent.com):
     stale-while-revalidate — serve instantly from cache when available
     and refresh in the background, so previously-seen Pokémon keep
     working offline while new ones still load normally online.

   skipWaiting()/clients.claim() below mean a new version of this
   file takes over almost immediately once fetched — app.js listens
   for that handover and reloads the page once, so an open tab
   converges to the latest build within a couple of seconds.
*/

const CACHE_VERSION = "v5";
const SHELL_CACHE = `fighter-shell-${CACHE_VERSION}`;
const RUNTIME_CACHE = `fighter-runtime-${CACHE_VERSION}`;

const APP_SHELL = [
  "./",
  "./index.html",
  "./manifest.webmanifest",
  "./style.css",
  "./app.js",
  "./game.js",
  "./gaming.png",
  "./ChatGPT Image Aug 17, 2026, 10_45_38 AM.png",
  "./icon-192.png",
  "./icon-512.png",
  "./icon-maskable-192.png",
  "./icon-maskable-512.png",
];

const RUNTIME_HOSTS = ["pokeapi.co", "raw.githubusercontent.com"];

self.addEventListener("install", (event) => {
  event.waitUntil(
    caches
      .open(SHELL_CACHE)
      .then((cache) =>
        Promise.all(
          APP_SHELL.map((url) =>
            cache.add(url).catch((err) => {
              // Don't let one missing/renamed asset block install —
              // just skip it and keep going.
              console.warn("[sw] skip caching", url, err);
            }),
          ),
        ),
      )
      .then(() => self.skipWaiting()),
  );
});

self.addEventListener("activate", (event) => {
  event.waitUntil(
    caches
      .keys()
      .then((keys) =>
        Promise.all(
          keys
            .filter((key) => key !== SHELL_CACHE && key !== RUNTIME_CACHE)
            .map((key) => caches.delete(key)),
        ),
      )
      .then(() => self.clients.claim()),
  );
});

function isRuntimeAsset(url) {
  return RUNTIME_HOSTS.some((host) => url.hostname === host);
}

async function staleWhileRevalidate(request) {
  const cache = await caches.open(RUNTIME_CACHE);
  const cached = await cache.match(request);

  const networkFetch = fetch(request)
    .then((response) => {
      if (response && response.ok) {
        cache.put(request, response.clone());
      }
      return response;
    })
    .catch(() => null);

  return cached || (await networkFetch) || Response.error();
}

async function networkFirst(request) {
  try {
    const response = await fetch(request);

    if (response && response.ok) {
      const cache = await caches.open(SHELL_CACHE);
      cache.put(request, response.clone());
    }

    return response;
  } catch (err) {
    // Offline (or the request failed outright) — fall back to
    // whatever was last cached for this exact request.
    const cached = await caches.match(request, { ignoreSearch: true });

    if (cached) {
      return cached;
    }

    // Nothing cached for this exact request either — for a page
    // navigation, fall back to the cached app shell page so the
    // game still boots offline.
    if (request.mode === "navigate") {
      const fallback = await caches.match("./index.html");
      if (fallback) return fallback;
    }

    throw err;
  }
}

self.addEventListener("fetch", (event) => {
  const { request } = event;

  if (request.method !== "GET") {
    return;
  }

  const url = new URL(request.url);

  if (isRuntimeAsset(url)) {
    event.respondWith(staleWhileRevalidate(request));
    return;
  }

  if (url.origin === self.location.origin) {
    event.respondWith(networkFirst(request));
  }
});
