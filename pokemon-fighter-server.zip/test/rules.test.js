"use strict";

const test = require("node:test");
const assert = require("node:assert");

const rules = require("../src/rules");

test("type chart: key matchups", () => {
  const eff = rules.typeEffectivenessMultiplier;

  assert.strictEqual(eff("electric", ["water"]), 2);
  assert.strictEqual(eff("electric", ["ground"]), 0, "ground is immune to electric");
  assert.strictEqual(eff("fire", ["water"]), 0.5);
  assert.strictEqual(eff("normal", ["ghost"]), 0);
  assert.strictEqual(eff("psychic", ["dark"]), 0);
  assert.strictEqual(eff("dragon", ["fairy"]), 0);
  assert.strictEqual(eff("fighting", ["normal", "rock"]), 4, "dual types multiply");
  assert.strictEqual(eff("grass", ["water", "ground"]), 4);
  assert.strictEqual(eff("not-a-type", ["water"]), 1, "unknown move type is neutral");
  assert.strictEqual(eff("fire", []), 1);
});

test("type chart: matches the official chart for every pair", () => {
  // Official gen 6+ super-effective pairs (attacker -> defenders).
  const superEffective = {
    fire: ["grass", "ice", "bug", "steel"],
    water: ["fire", "ground", "rock"],
    electric: ["water", "flying"],
    grass: ["water", "ground", "rock"],
    ice: ["grass", "ground", "flying", "dragon"],
    fighting: ["normal", "ice", "rock", "dark", "steel"],
    poison: ["grass", "fairy"],
    ground: ["fire", "electric", "poison", "rock", "steel"],
    flying: ["grass", "fighting", "bug"],
    psychic: ["fighting", "poison"],
    bug: ["grass", "psychic", "dark"],
    rock: ["fire", "ice", "flying", "bug"],
    ghost: ["psychic", "ghost"],
    dragon: ["dragon"],
    dark: ["psychic", "ghost"],
    steel: ["ice", "rock", "fairy"],
    fairy: ["fighting", "dragon", "dark"],
  };

  for (const [atk, defs] of Object.entries(superEffective)) {
    for (const def of defs) {
      assert.strictEqual(
        rules.typeEffectivenessMultiplier(atk, [def]),
        2,
        atk + " should be super effective against " + def,
      );
    }
  }
});

test("legendary detection handles PokéAPI form names", () => {
  const is = (name) => rules.isLegendaryPokemon({ name });

  for (const n of [
    "mewtwo",
    "mew",
    "landorus-incarnate",
    "tornadus-incarnate",
    "deoxys-normal",
    "keldeo-ordinary",
    "zygarde-50",
    "urshifu-single-strike",
    "ho-oh",
    "tapu-koko",
    "type-null",
  ]) {
    assert.ok(is(n), n + " should be legendary/mythical");
  }

  for (const n of ["raichu", "pikachu", "charizard", "mr-mime", "eevee"]) {
    assert.ok(!is(n), n + " should NOT be legendary");
  }

  assert.ok(!rules.isLegendaryPokemon(null));
  assert.ok(!rules.isLegendaryPokemon({}));
});

test("legendary multipliers are the agreed values", () => {
  assert.strictEqual(rules.LEGENDARY_DAMAGE_DEALT_MULT, 1.65);
  assert.strictEqual(rules.LEGENDARY_DAMAGE_TAKEN_MULT, 0.55);
});
