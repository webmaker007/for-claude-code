"use strict";

const test = require("node:test");
const assert = require("node:assert");

const sim = require("../src/battle-sim");

const mon = (name, type, moveType, damage) => ({
  name,
  types: [{ type: { name: type } }],
  hp: 100,
  move: {
    name: "Move",
    type: moveType,
    damage,
    range: 300,
    projectile: false,
    speed: 12,
    color: "#ffffff",
  },
});

/* Puts the fighters in melee range and has `attackerSide` attack
   until the first hit lands. Returns that hit event and the match. */
function firstHit(teamA, teamB, attackerSide, setup) {
  const m = sim.createMatch([teamA], [teamB]);

  m.fighters.a.x = 500;
  m.fighters.b.x = 560;

  if (setup) setup(m);

  for (let i = 0; i < 600; i++) {
    sim.queueActions(m, attackerSide, ["attack"]);
    sim.step(m, 1);

    if (m.events.length) return { event: m.events[0], match: m };
  }

  throw new Error("no hit landed");
}

test("a normal hit deals the move's damage", () => {
  const { event } = firstHit(
    mon("rattata", "normal", "normal", 20),
    mon("pidgey", "normal", "normal", 20),
    "a",
  );

  assert.strictEqual(event.damage, 20);
  assert.strictEqual(event.eff, 1);
});

test("super effective hits deal double", () => {
  const { event } = firstHit(
    mon("pikachu", "electric", "electric", 20),
    mon("squirtle", "water", "water", 20),
    "a",
  );

  assert.strictEqual(event.eff, 2);
  assert.strictEqual(event.damage, 40);
});

test("immune targets take nothing and aren't knocked back", () => {
  const { event, match } = firstHit(
    mon("pikachu", "electric", "electric", 20),
    mon("geodude", "ground", "rock", 20),
    "a",
  );

  assert.strictEqual(event.eff, 0);
  assert.strictEqual(event.damage, 0);
  assert.strictEqual(match.fighters.b.hp, 100);
  assert.strictEqual(match.fighters.a.combo, 0, "no combo for an immune hit");
});

test("Raichu and Mewtwo no longer hit/defend the same online", () => {
  const raichu = mon("raichu", "electric", "electric", 20);
  const mewtwo = mon("mewtwo", "psychic", "psychic", 20);

  const raichuHitsMewtwo = firstHit(raichu, mewtwo, "a").event.damage;
  const mewtwoHitsRaichu = firstHit(raichu, mewtwo, "b").event.damage;

  // Legendary defender takes ~45% less; legendary attacker deals ~65% more.
  assert.strictEqual(raichuHitsMewtwo, Math.round(20 * 0.55));
  assert.strictEqual(mewtwoHitsRaichu, Math.round(20 * 1.65));
  assert.ok(mewtwoHitsRaichu > raichuHitsMewtwo * 2);
});

test("server-provided types override what the client claimed", () => {
  // Client claims "ghost" (normal-immune) but the server looked up "normal".
  const liar = mon("rattata", "ghost", "normal", 20);

  liar.simTypes = ["normal"];

  const { event } = firstHit(mon("rattata", "normal", "normal", 20), liar, "a");

  assert.strictEqual(event.eff, 1, "simTypes must win over client types");
  assert.strictEqual(event.damage, 20);
});

test("blocking cuts damage to a quarter (minimum 3)", () => {
  const { event } = firstHit(
    mon("rattata", "normal", "normal", 20),
    mon("pidgey", "normal", "normal", 20),
    "a",
    (m) => {
      m.fighters.b.blocking = true;
    },
  );

  assert.strictEqual(event.blocked, true);
  assert.strictEqual(event.damage, 5);
});

test("snapshots carry the hit events", () => {
  const m = sim.createMatch(
    [mon("a", "normal", "normal", 20)],
    [mon("b", "normal", "normal", 20)],
  );

  sim.step(m, 1);

  assert.ok(Array.isArray(sim.snapshot(m).events));
});
