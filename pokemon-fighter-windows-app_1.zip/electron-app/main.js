const { app, BrowserWindow, Menu, session, ipcMain, shell } = require("electron");
const path = require("path");
const http = require("http");
const crypto = require("crypto");

/* ============================================================
   GOOGLE SIGN-IN (desktop OAuth flow)

   The browser-based "Google Identity Services" popup (what the web
   version of this app uses) can't work inside a packaged desktop app
   — Google requires the page's origin to be on an "Authorized
   JavaScript origins" allowlist, and a local file:// app has no such
   origin to authorize.

   Desktop apps use a different, Google-sanctioned flow instead:
   open the person's real system browser to sign in there (a trusted,
   non-embedded context Google is happy with), then catch the
   redirect on a temporary local server and exchange the code for
   tokens here in the main process.

   SETUP REQUIRED — this won't work until you fill these in:
   1. In Google Cloud Console (same project as your existing Web
      Client ID), create a NEW OAuth Client ID of type "Desktop app".
   2. Paste its Client ID and Client Secret below.
   (A Desktop app client automatically supports the loopback redirect
   this code uses — no redirect URI needs to be registered manually.)
============================================================ */

const GOOGLE_DESKTOP_CLIENT_ID = "942889695165-4pleamb0n258igvjpbmpa67uhi8ha923.apps.googleusercontent.com";
const GOOGLE_DESKTOP_CLIENT_SECRET = "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";

function base64url(buffer) {
  return buffer
    .toString("base64")
    .replace(/\+/g, "-")
    .replace(/\//g, "_")
    .replace(/=+$/, "");
}

function signInWithGoogle() {
  return new Promise((resolve) => {
    if (
      !GOOGLE_DESKTOP_CLIENT_ID ||
      GOOGLE_DESKTOP_CLIENT_ID.startsWith("YOUR_DESKTOP_CLIENT_ID")
    ) {
      resolve({
        ok: false,
        error:
          "Desktop Google Sign-In isn't set up yet — add a Desktop OAuth Client ID/Secret in main.js.",
      });
      return;
    }

    const codeVerifier = base64url(crypto.randomBytes(32));

    const codeChallenge = base64url(
      crypto.createHash("sha256").update(codeVerifier).digest(),
    );

    const state = base64url(crypto.randomBytes(16));

    let settled = false;

    const finish = (result) => {
      if (settled) return;
      settled = true;
      resolve(result);
    };

    const server = http.createServer(async (req, res) => {
      try {
        const url = new URL(req.url, "http://127.0.0.1");

        const code = url.searchParams.get("code");
        const returnedState = url.searchParams.get("state");
        const errorParam = url.searchParams.get("error");

        res.setHeader("Content-Type", "text/html; charset=utf-8");

        if (errorParam) {
          res.end(
            "<html><body style='font-family:sans-serif;padding:40px;text-align:center'>" +
              "<h2>Sign-in cancelled</h2><p>You can close this tab and return to Pok\u00e9mon Fighter.</p></body></html>",
          );

          finish({ ok: false, error: errorParam });

          server.close();

          return;
        }

        if (!code || returnedState !== state) {
          res.end(
            "<html><body style='font-family:sans-serif;padding:40px;text-align:center'>" +
              "<h2>Something went wrong</h2><p>You can close this tab and try again in the app.</p></body></html>",
          );

          finish({ ok: false, error: "invalid_state_or_code" });

          server.close();

          return;
        }

        const { address, port } = server.address();

        const redirectUri = `http://127.0.0.1:${port}/`;

        const tokenRes = await fetch("https://oauth2.googleapis.com/token", {
          method: "POST",
          headers: { "Content-Type": "application/x-www-form-urlencoded" },
          body: new URLSearchParams({
            client_id: GOOGLE_DESKTOP_CLIENT_ID,
            client_secret: GOOGLE_DESKTOP_CLIENT_SECRET,
            code,
            code_verifier: codeVerifier,
            grant_type: "authorization_code",
            redirect_uri: redirectUri,
          }),
        });

        const tokenJson = await tokenRes.json();

        if (!tokenRes.ok || !tokenJson.id_token) {
          res.end(
            "<html><body style='font-family:sans-serif;padding:40px;text-align:center'>" +
              "<h2>Sign-in failed</h2><p>You can close this tab and try again in the app.</p></body></html>",
          );

          finish({
            ok: false,
            error: tokenJson.error || "token_exchange_failed",
          });

          server.close();

          return;
        }

        res.end(
          "<html><body style='font-family:sans-serif;padding:40px;text-align:center'>" +
            "<h2>You're signed in \u2705</h2><p>You can close this tab and return to Pok\u00e9mon Fighter.</p></body></html>",
        );

        finish({ ok: true, idToken: tokenJson.id_token });

        server.close();
      } catch (err) {
        try {
          res.end("Something went wrong. You can close this tab.");
        } catch (e) {
          /* response may already be closed */
        }

        finish({ ok: false, error: String(err) });

        server.close();
      }
    });

    server.listen(0, "127.0.0.1", () => {
      const { port } = server.address();

      const redirectUri = `http://127.0.0.1:${port}/`;

      const authUrl =
        "https://accounts.google.com/o/oauth2/v2/auth?" +
        new URLSearchParams({
          client_id: GOOGLE_DESKTOP_CLIENT_ID,
          redirect_uri: redirectUri,
          response_type: "code",
          scope: "openid email profile",
          code_challenge: codeChallenge,
          code_challenge_method: "S256",
          state,
          prompt: "select_account",
        }).toString();

      shell.openExternal(authUrl);
    });

    // Don't hang forever if the person never finishes signing in.
    setTimeout(() => {
      if (!settled) {
        finish({ ok: false, error: "timed_out" });

        try {
          server.close();
        } catch (e) {
          /* already closed */
        }
      }
    }, 5 * 60 * 1000);
  });
}

ipcMain.handle("google-sign-in", () => signInWithGoogle());

/* ============================================================
   WINDOW
============================================================ */

let mainWindow = null;

async function createWindow() {
  // This app has no use for service workers (it's already a native
  // desktop app — nothing to "install" or cache offline). An earlier
  // build briefly registered one by mistake, and once a service worker
  // is registered for an origin, Electron keeps it active across future
  // launches until it's explicitly unregistered — and since fetch()
  // can't load file:// URLs, a leftover one intercepting requests to
  // index.html will permanently fail to load the app with ERR_FAILED.
  // Wipe any leftover registration/cache on every startup so that can
  // never happen again, regardless of what ran before.
  await session.defaultSession.clearStorageData({
    storages: ["serviceworkers", "cachestorage"],
  });

  mainWindow = new BrowserWindow({
    width: 1366,
    height: 860,
    minWidth: 900,
    minHeight: 600,
    backgroundColor: "#0b1220",
    icon: path.join(__dirname, "build", "icon.ico"),
    autoHideMenuBar: true,
    webPreferences: {
      preload: path.join(__dirname, "preload.js"),
      contextIsolation: true,
      nodeIntegration: false,
      sandbox: true,
    },
  });

  // Hide the default menu bar entirely (this is a game, not a document app).
  Menu.setApplicationMenu(null);

  // F12 (or Ctrl+Shift+I, in case F12 is mapped to a hardware function
  // like brightness on some laptops) opens DevTools — useful for
  // diagnosing blocked network requests since the menu bar is hidden.
  mainWindow.webContents.on("before-input-event", (event, input) => {
    const isF12 = input.type === "keyDown" && input.key === "F12";

    const isCtrlShiftI =
      input.type === "keyDown" &&
      input.key.toLowerCase() === "i" &&
      input.control &&
      input.shift;

    if (isF12 || isCtrlShiftI) {
      mainWindow.webContents.toggleDevTools();
    }
  });

  mainWindow.loadFile(path.join(__dirname, "index.html"));

  mainWindow.on("closed", () => {
    mainWindow = null;
  });
}

app.whenReady().then(createWindow);

app.on("window-all-closed", () => {
  if (process.platform !== "darwin") {
    app.quit();
  }
});

app.on("activate", () => {
  if (BrowserWindow.getAllWindows().length === 0) {
    createWindow();
  }
});
